<?php
session_start();
include("User.php");
$x = new User;


if($x -> IsLoggedIn())
    $logined_id = $_SESSION["username"];
else
    header('Location: index.php');

$pw="";
$userdb="root";
$server="localhost";
$db="chess4u";
$charset="utf8";
$opt=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];

$connection = new PDO("mysql: host=$server; dbname=$db; charset=$charset",$userdb,$pw,$opt);
if(!$connection)
{
    error_log("Error!");
    die("Datenbankfehler");
}
$statement1 = $connection->prepare("SELECT * FROM `spieler` WHERE id=:id");
$statement1->bindParam(':id',$logined_id,PDO::PARAM_STR);
$statement1->execute();
while ($row1 = $statement1->fetch())
{
    extract($row1);
    $logined = $row1['nachname'];
}

?>
<html>
<head>
    <title>chess4u -
        <?php
        echo $logined;
        ?>
    </title>

    <link rel="shortcut icon" href="http://chess4u.at/img/favicon.ico" type="image/x-icon">
    <link rel="icon" href="http://chess4u.at/img/favicon.ico" type="image/x-icon">

    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.css">
    <link rel="stylesheet" href="css2/style.css">

    <link rel="stylesheet" href="css2/inc/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css2/inc/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css2/style2.css">
    <link rel="stylesheet" href="css2/meins.css">
    <link rel="stylesheet" href="css2/mobile.css">
</head>
<body>


    <nav id="main-navbar" class="navbar navbar-default" role="navigation"> <!-- Classes: navbar-default, navbar-inverse, navbar-fixed-top, navbar-fixed-bottom, navbar-transparent. Note: If you use non-transparent navbar, set "height: 98px;" to #header -->
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="body">CHESS4U</a>
            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <?php
                            echo $logined;
                            ?> <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <form class="navbar-form" action="?page=log" method="POST">
                                <li class="text-center">
                                    <label for=""><a id="dropdownLink" href="logout.php">Logout</a></label>
                                </li>
                            </form>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

<div class="container" id="formDiv">
    <div class="row main">
        <div class="panel-heading">
            <div class="panel-title text-center">
<!--                <h5>login</h5>-->


                <?php
                $pw="";
                $userdb="root";
                $server="localhost";
                $db="chess4u";
                $charset="utf8";
                $opt=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];

                $connection = new PDO("mysql: host=$server; dbname=$db; charset=$charset",$userdb,$pw,$opt);
                if(!$connection)
                {
                    error_log("Error!");
                    die("Datenbankfehler");
                }
                $statement = $connection->prepare("SELECT *, DATE_FORMAT(spielbeginn, '%d.%c.%Y %H:%i:%s') AS 'spieldatum' FROM `schachspiel` WHERE (`spieler_weiß` = :sp OR `spieler_schwarz` = :sp) and schachspiel_id = :sid");
                //SELECT spieler.vorname, spieler.nachname, schachspiel.schachspiel_id FROM `schachspiel` JOIN spieler ON schachspiel.spieler_weiß = spieler.id WHERE `spieler_weiß` = 1 OR `spieler_schwarz` = 1
                $statement->bindParam(':sp',$_SESSION["username"],PDO::PARAM_STR);
                $statement->bindParam(':sid',$_GET["sid"],PDO::PARAM_STR);
                $statement->execute();

                ?>

                <table class="table table-bordered table-responsive table-striped">
                    <tr>
                        <th class="text-center">Spiel Nr.</th>
                        <th class="text-center">Spieler Weiß</th>
                        <!--                                <th>Spieler Weiß Nachname</th>-->
                        <th class="text-center">Spieler Schwarz</th>
                        <!--                                <th>Spieler Schwarz Nachname</th>-->
                        <th class="text-center">Datum & Zeit</th>
                    </tr>

                    <?php



                    while ($row = $statement->fetch())
                    {
                        extract($row);

                        $spielerW = $spieler_weiß;
                        $spielerS = $spieler_schwarz;


                        ?>

                        <?php
                    }

                    $spielerWName = "";
                    $spielerSName = "";

                    if($spielerW == $_SESSION["username"])
                    {
                        $spielerWName = "<span class='glyphicon glyphicon-user'></span>";
                    }
                    else {
                        $pw="";
                        $userdb="root";
                        $server="localhost";
                        $db="chess4u";
                        $charset="utf8";
                        $opt=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
                            PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];

                        $connection = new PDO("mysql: host=$server; dbname=$db; charset=$charset",$userdb,$pw,$opt);
                        if(!$connection)
                        {
                            error_log("Error!");
                            die("Datenbankfehler");
                        }
                        $statementSW = $connection->prepare("SELECT `vorname`, `nachname` FROM `spieler` WHERE id = :sid");
                        $statementSW->bindParam(':sid',$spielerW,PDO::PARAM_STR);
                        $statementSW->execute();

                        while ($rowSW = $statementSW->fetch())
                        {
                            extract($rowSW);

                            $spielerWName = $vorname." ".$nachname;
                        }
                    }

                    if($spielerS == $_SESSION["username"])
                    {
                        $spielerSName = "<span class='glyphicon glyphicon-user'></span>";
                    }
                    else {
                        $pw="";
                        $userdb="root";
                        $server="localhost";
                        $db="chess4u";
                        $charset="utf8";
                        $opt=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
                            PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];

                        $connection = new PDO("mysql: host=$server; dbname=$db; charset=$charset",$userdb,$pw,$opt);
                        if(!$connection)
                        {
                            error_log("Error!");
                            die("Datenbankfehler");
                        }
                        $statementSS = $connection->prepare("SELECT `vorname`, `nachname` FROM `spieler` WHERE id = :sid");
                        $statementSS->bindParam(':sid',$spielerS,PDO::PARAM_STR);
                        $statementSS->execute();

                        while ($rowSS = $statementSS->fetch())
                        {
                            extract($rowSS);

                            $spielerSName = $vorname." ".$nachname;
                        }
                    }


                    ?>
                    <tr>
                        <td class="text-center"><?php echo $schachspiel_id?></td>
                        <td class="text-center"><?php echo $spielerWName?></td>
                        <td class="text-center"><?php echo $spielerSName?></td>
                        <td class="text-center"><?php echo $spieldatum?></td>
                    </tr>
                </table>

                <div style="padding-left: 50px;" class="container col-md-4 col-sm-4 col-xs-4">
                    <h2 class="text-center">Partie 1</h2><br>
                    <h4><span style="color: #757778;">Weiß: </span><?php echo $spielerWName?></h4>
                    <h4><span style="color: #65d9f2;">Schwarz: </span><?php echo $spielerSName?></h4>

                    <br>
                    <p id="schritte">
                        <span title="Anfang" id="schrittAnfang"> <| </span>
                        <span title="Einen ganzen Zug zurück" id="schrittZurueck"> << </span> |
                        <span title="Einen Zug eines Spielers zurück" id="schrittBissiZurueck"> < </span>|
                        <span title="Einen Zug eines Spielers weiter" id="schrittBissiWeiter"> > </span> |
                        <span title="Einen ganzen Zug weiter" id="schrittWeiter"> >> </span>
                        <span title="Ende" id="schrittEnde"> |> </span>
                    </p>
                    <br>

                    <ul>
                        <li><a href="#kNotationTables" aria-controls="kNotationTables" role="tab" data-toggle="tab">Kurze Notation</a></li>
                        <li><a href="#lNotationTables" aria-controls="lNotationTables" role="tab" data-toggle="tab">Lange Notation</a></li>
                    </ul>
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane" id="kNotationTables">

                            <table id="kNotationsTable" class="table table-striped table-responsive table-bordered"> <!--id="kNotationsTable"-->
                                <tr>
                                    <th class="text-center">NR</th>
                                    <th class="text-center"><?php echo $spielerWName?></th>
                                    <th class="text-center"><?php echo $spielerSName?></th>
                                </tr>
                            </table>

                            <table hidden id="kNotationsTableW" class="table table-striped table-responsive table-bordered"><!--hidden-->
                                <tr>
                                    <th class="text-center">NR</th>
                                    <th class="text-center"><?php echo $spielerWName?></th>
                                </tr>
                                <?php
                                $statementW1 = $connection->prepare("SELECT * FROM `spielzuege` JOIN schachfigur ON figur_id = schachfigur.id JOIN schachspiel ON `spiel_id` = schachspiel.schachspiel_id WHERE spiel_id=:id and `spieler_id` = schachspiel.spieler_weiß;");
                                $statementW1->bindParam(':id',$_GET["sid"],PDO::PARAM_STR);
                                $statementW1->execute();
                                while ($rowW1 = $statementW1->fetch())
                                {
                                    extract($rowW1);

                                    ?>
                                    <tr>
                                    <td><?php echo $zugnummer ?></td>
                                    <td><?php echo $neue_position ?></td>
                                    </tr><?php
                                }
                                ?>
                            </table>
                            <table hidden id="kNotationsTableS" class="table table-striped table-responsive table-bordered">
                                <tr>
                                    <th class="text-center">NR</th>
                                    <th class="text-center"><?php echo $spielerSName?></th>
                                </tr>
                                <?php
                                $statementS1 = $connection->prepare("SELECT * FROM `spielzuege` JOIN schachfigur ON figur_id = schachfigur.id JOIN schachspiel ON `spiel_id` = schachspiel.schachspiel_id WHERE spiel_id=:id and `spieler_id` = schachspiel.spieler_schwarz;");
                                $statementS1->bindParam(':id',$_GET["sid"],PDO::PARAM_STR);
                                $statementS1->execute();
                                while ($rowS1 = $statementS1->fetch())
                                {
                                    extract($rowS1);
                                    ?>
                                    <tr>
                                    <td><?php echo $zugnummer ?></td>
                                    <td><?php echo $neue_position ?></td>
                                    </tr><?php
                                }
                                ?>
                            </table><!--hidden-->
                        </div>
                        <div role="tabpanel" class="tab-pane" id="lNotationTables">
                            <table id="lNotationsTable" class="table table-striped table-responsive table-bordered"> <!--id="kNotationsTable"-->
                                <tr>
                                    <th class="text-center">NR</th>
                                    <th class="text-center"><?php echo $spielerWName?></th>
                                    <th class="text-center"><?php echo $spielerSName?></th>
                                </tr>
                            </table>
                            <table hidden id="lNotationsTableW" class="table table-striped table-responsive table-bordered"><!--hidden-->
                                <tr>
                                    <th class="text-center">NR</th>
                                    <th class="text-center"><?php echo $spielerWName?></th>
                                </tr>
                                <?php
                                $statementW2 = $connection->prepare("SELECT * FROM `spielzuege` JOIN schachfigur ON figur_id = schachfigur.id JOIN schachspiel ON `spiel_id` = schachspiel.schachspiel_id WHERE spiel_id=:id and `spieler_id` = schachspiel.spieler_weiß;");
                                $statementW2->bindParam(':id',$_GET["sid"],PDO::PARAM_STR);
                                $statementW2->execute();
                                while ($rowW2 = $statementW2->fetch())
                                {
                                    extract($rowW2);
                                    $figurBuchstabe = substr($name, 0,1);
                                    if($figurBuchstabe == 'B')
                                        $figurBuchstabe = "";
                                    ?>
                                    <tr>
                                    <td><?php echo $zugnummer ?></td>
                                    <td><span class="SFig"><?php echo $figurBuchstabe?></span><span class="SAP"><?php echo $alte_position ?></span>-<span class="SNP"><?php echo $neue_position?></span></td>
                                    </tr><?php
                                }
                                ?>
                            </table>
                            <table hidden id="lNotationsTableS" class="table table-striped table-responsive table-bordered">
                                <tr>

                                    <th class="text-center">NR</th>
                                    <th class="text-center"><?php echo $spielerSName?></th>
                                </tr>
                                <?php
                                $statementS2 = $connection->prepare("SELECT * FROM `spielzuege` JOIN schachfigur ON figur_id = schachfigur.id JOIN schachspiel ON `spiel_id` = schachspiel.schachspiel_id WHERE spiel_id=:id and `spieler_id` = schachspiel.spieler_schwarz;");
                                $statementS2->bindParam(':id',$_GET["sid"],PDO::PARAM_STR);
                                $statementS2->execute();
                                while ($rowS2 = $statementS2->fetch())
                                {
                                    extract($rowS2);
                                    $figurBuchstabe = substr($name, 0,1);
                                    if($figurBuchstabe == 'B')
                                        $figurBuchstabe = "";
                                    ?>
                                    <tr>
                                    <td><?php echo $zugnummer ?></td>
                                    <td><span class="SFig"><?php echo $figurBuchstabe?></span><span class="SAP"><?php echo $alte_position ?></span>-<span class="SNP"><?php echo $neue_position?></span></td>
                                    </tr><?php
                                }
                                ?>
                            </table><!--hidden-->
                        </div>
                    </div>

                   <!-- <button class="btn btn-default" type="submit">Speichern</button>
                    <button class="btn btn-default" type="submit">Drucken</button>-->
                    <br><br>
                </div>
                <div id="divWeiss" class="container col-md-5 col-md-offset-3 col-sm-5 col-sm-offset-2 col-xs-12">
                    <div class="text-center" id="afs">
                        <span id="afsd" border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-queen afsFigur'></span>
                        <span id="afst1" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-tower afsFigur'></span>
                        <span id="afst2" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-tower afsFigur'></span>
                        <span id="afsl1" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-pawn afsFigur'></span>
                        <span id="afsl2" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-pawn afsFigur'></span>
                        <span id="afss1" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-knight afsFigur'></span>
                        <span id="afss2" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-knight afsFigur'></span>
                        <span id="afsb1" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop afsFigur'></span>
                        <span id="afsb2" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop afsFigur'></span>
                        <span id="afsb3" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop afsFigur'></span>
                        <span id="afsb4" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop afsFigur'></span>
                        <span id="afsb5" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop afsFigur'></span>
                        <span id="afsb6" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop afsFigur'></span>
                        <span id="afsb7" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop afsFigur'></span>
                        <span id="afsb8" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop afsFigur'></span>
                    </div>
                    <table id="schachbrettWeiss">
                        <tr>
                            <th class="text-center"></th>
                            <th class="text-center">A</th>
                            <th class="text-center">B</th>
                            <th class="text-center">C</th>
                            <th class="text-center">D</th>
                            <th class="text-center">E</th>
                            <th class="text-center">F</th>
                            <th class="text-center">G</th>
                            <th class="text-center">H</th>
                            <th class="text-center"></th>
                        </tr>
                        <?php
                        include('brettWeiss.php');
                        ?>
                        <tr>
                            <th class="text-center"></th>
                            <th class="text-center">A</th>
                            <th class="text-center">B</th>
                            <th class="text-center">C</th>
                            <th class="text-center">D</th>
                            <th class="text-center">E</th>
                            <th class="text-center">F</th>
                            <th class="text-center">G</th>
                            <th class="text-center">H</th>
                            <th class="text-center"></th>
                        </tr>
                    </table>
                    <div class="text-center" id="afw">
                        <span id="afwd" border='1px solid black' style='color: #757778' class='glyphicon glyphicon-queen afwFigur'></span>
                        <span id="afwt1" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-tower afwFigur'></span>
                        <span id="afwt2" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-tower afwFigur'></span>
                        <span id="afwl1" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-pawn afwFigur'></span>
                        <span id="afwl2" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-pawn afwFigur'></span>
                        <span id="afws1" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-knight afwFigur'></span>
                        <span id="afws2" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-knight afwFigur'></span>
                        <span id="afwb1" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop afwFigur'></span>
                        <span id="afwb2" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop afwFigur'></span>
                        <span id="afwb3" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop afwFigur'></span>
                        <span id="afwb4" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop afwFigur'></span>
                        <span id="afwb5" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop afwFigur'></span>
                        <span id="afwb6" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop afwFigur'></span>
                        <span id="afwb7" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop afwFigur'></span>
                        <span id="afwb8" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop afwFigur'></span>
                    </div>
                </div>

            </div>
            <a style="margin-top: 100px;" href="login.php">zurück</a>
        </div>
    </div>
</div>

<script src="bower_components/jquery/dist/jquery.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.js"></script>
<script src="js2/script.js"></script>


<?php



?>
</body>
</html>