<html>
<head>
    <title>chess4u - prestest</title>
    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.css">
    <link rel="stylesheet" href="css2/style.css">
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <div class="navbar-left">
                <a href="#" class="navbar-brand">Chess4U</a>
            </div>

            <ul class="nav navbar-nav navbar-right">
                <li class="active"><a href="#">History</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Angemeldet als: <b>Lewitsch</b><span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <form class="navbar-form" action="index.php/?page=log" method="POST">
                            <li>
                                <div class="form-group">
                                    <label class="sr-only" for="exampleInputEmail3">Email address</label>
                                    <input type="email" class="form-control" id="inputEmailLogin" name="inputEmailLogin" placeholder="Email">
                                </div>
                            </li>
                            <li role="separator" class="divider"></li>
                            <li>
                                <div class="form-group">
                                    <label class="sr-only" for="exampleInputPassword3">Password</label>
                                    <input type="password" class="form-control" id="inputPasswortLogin" name="inputPasswortLogin" placeholder="Password">
                                </div>
                            </li>
                            <li role="separator" class="divider"></li>
                            <li>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox"> Remember me
                                    </label>
                                </div>
                            </li>
                            <li role="separator" class="divider"></li>
                            <li>
                                <button type="submit" class="btn btn-default">Sign in</button>
                            </li>
                            <li role="separator" class="divider"></li>
                            <li>
                                <label for="">Passwort vergessen?</label>
                            </li>
                        </form>
                    </ul>
                </li>

            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>

<div class="container" id="formDiv">
    <div id="divAll" class="container col-md-12">
        <div style="padding-left: 50px;" class="container col-md-4">
            <h2 class="text-center">Partie 1</h2><br>
            <h4>Gegner: Kirchknopf</h4>
            <h4>Sieger: Lewitsch (<span class="glyphicon glyphicon-user"></span>)</h4>

            <br><br>

            <ul>
                <li><b><u>kurze Notation</u></b></li>
                <li>Lange Notation</li>
            </ul>
            <table class="table table-striped table-responsive table-bordered">
                <tr>
                    <th class="text-center">NR</th>
                    <th class="text-center">Lewitsch (<span class="glyphicon glyphicon-user"></span>)</th>
                    <th class="text-center">Kirchknop</th>
                </tr>
                <tr>
                    <td class="text-center">1</td>
                    <td class="text-center">e4</td>
                    <td class="text-center">e5</td>
                </tr>
                <tr>
                    <td class="text-center">2</td>
                    <td class="text-center">Lc4</td>
                    <td class="text-center">Sc6</td>
                </tr>
                <tr>
                    <td class="text-center">Df3</td>
                    <td class="text-center">Df3</td>
                    <td class="text-center">Lc5</td>
                </tr>
                <tr>
                    <td class="text-center">4</td>
                    <td class="text-center">Dxf7#</td>
                    <td class="text-center"></td>
                </tr>
            </table>

            <button class="btn btn-default" type="submit">Drucken</button>
        </div>
        <div id="divWeiss" class="container col-md-5 col-md-offset-2">
                <table id="schachbrettWeiss">
                    <tr>
                        <th class="text-center"></th>
                        <th class="text-center">A</th>
                        <th class="text-center">B</th>
                        <th class="text-center">C</th>
                        <th class="text-center">D</th>
                        <th class="text-center">E</th>
                        <th class="text-center">F</th>
                        <th class="text-center">G</th>
                        <th class="text-center">H</th>
                        <th class="text-center"></th>
                    </tr>
                    <?php
                    include('brettWeiss.php');
                    ?>
                    <tr>
                        <th class="text-center"></th>
                        <th class="text-center">A</th>
                        <th class="text-center">B</th>
                        <th class="text-center">C</th>
                        <th class="text-center">D</th>
                        <th class="text-center">E</th>
                        <th class="text-center">F</th>
                        <th class="text-center">G</th>
                        <th class="text-center">H</th>
                        <th class="text-center"></th>
                    </tr>
                </table>
        </div>
    </div>
</div>

<script src="bower_components/jquery/dist/jquery.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.js"></script>

<script>
    var figurenObjBlack = {
        //figuren: ["K", "D", "L1", "L2", "S1", "S2", "T1", "T2", "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8"]
        figuren: ["<span class='glyphicon glyphicon-king'></span>",
            "<span class='glyphicon glyphicon-queen'></span>",
            "<span class='glyphicon glyphicon-pawn'></span>",
            "<span class='glyphicon glyphicon-knight'></span>",
            "<span class='glyphicon glyphicon-tower'></span>",
            "<span class='glyphicon glyphicon-bishop'></span>"]
    };

    var figurenObjWhite = {
        //figuren: ["K", "D", "L1", "L2", "S1", "S2", "T1", "T2", "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8"]
        figuren: ["<span class='glyphicon glyphicon-king'></span>",
            "<span class='glyphicon glyphicon-queen'></span>",
            "<span class='glyphicon glyphicon-pawn'></span>",
            "<span class='glyphicon glyphicon-knight'></span>",
            "<span class='glyphicon glyphicon-tower'></span>",
            "<span class='glyphicon glyphicon-bishop'></span>"]
    };

    var koenigWeiss = figurenObjWhite.figuren[0];
    var koenigSchwarz = figurenObjBlack.figuren[0];
    var dameWeiss = figurenObjWhite.figuren[1];
    var dameSchwarz = figurenObjBlack.figuren[1];
    var laeufer1Weiss = figurenObjWhite.figuren[2];
    var laeufer1Schwarz = figurenObjBlack.figuren[2];
    var laeufer2Weiss = figurenObjWhite.figuren[2];
    var laeufer2Schwarz = figurenObjBlack.figuren[2];
    var springer1Weiss = figurenObjWhite.figuren[3];
    var springer1Schwarz = figurenObjBlack.figuren[3];
    var springer2Weiss = figurenObjWhite.figuren[3];
    var springer2Schwarz = figurenObjBlack.figuren[3];
    var turm1Weiss = figurenObjWhite.figuren[4];
    var turm1Schwarz = figurenObjBlack.figuren[4];
    var turm2Weiss = figurenObjWhite.figuren[4];
    var turm2Schwarz = figurenObjBlack.figuren[4];
    var bauer1Weiss = figurenObjWhite.figuren[5];
    var bauer2Weiss = figurenObjWhite.figuren[5];
    var bauer3Weiss = figurenObjWhite.figuren[5];
    var bauer4Weiss = figurenObjWhite.figuren[5];
    var bauer5Weiss = figurenObjWhite.figuren[5];
    var bauer6Weiss = figurenObjWhite.figuren[5];
    var bauer7Weiss = figurenObjWhite.figuren[5];
    var bauer8Weiss = figurenObjWhite.figuren[5];
    var bauer1Schwarz = figurenObjBlack.figuren[5];
    var bauer2Schwarz = figurenObjBlack.figuren[5];
    var bauer3Schwarz = figurenObjBlack.figuren[5];
    var bauer4Schwarz = figurenObjBlack.figuren[5];
    var bauer5Schwarz = figurenObjBlack.figuren[5];
    var bauer6Schwarz = figurenObjBlack.figuren[5];
    var bauer7Schwarz = figurenObjBlack.figuren[5];
    var bauer8Schwarz = figurenObjBlack.figuren[5];
    document.getElementsByClassName("weissE1")[0].innerHTML = koenigWeiss;
    document.getElementsByClassName("weissE1")[0].style.color = "white";
    document.getElementsByClassName("weissE8")[0].innerHTML = koenigSchwarz;
    document.getElementsByClassName("weissE8")[0].style.color = "#65d9f2";
    document.getElementsByClassName("weissF7")[0].innerHTML = dameWeiss;
    document.getElementsByClassName("weissF7")[0].style.color = "white";
    //document.getElementsByClassName("weissF7")[0].style.border = "0px 1px 1px 0px solid #65d9f2";
    document.getElementsByClassName("weissD8")[0].innerHTML = dameSchwarz;
    document.getElementsByClassName("weissD8")[0].style.color = "#65d9f2";
    document.getElementsByClassName("weissC1")[0].innerHTML = laeufer1Weiss;
    document.getElementsByClassName("weissC1")[0].style.color = "white";
    document.getElementsByClassName("weissC8")[0].innerHTML = laeufer1Schwarz;
    document.getElementsByClassName("weissC8")[0].style.color = "#65d9f2";
    document.getElementsByClassName("weissC4")[0].innerHTML = laeufer2Weiss;
    document.getElementsByClassName("weissC4")[0].style.color = "white";
    document.getElementsByClassName("weissC5")[0].innerHTML = laeufer2Schwarz;
    document.getElementsByClassName("weissC5")[0].style.color = "#65d9f2";
    document.getElementsByClassName("weissB1")[0].innerHTML = springer1Weiss;
    document.getElementsByClassName("weissB1")[0].style.color = "white";
    document.getElementsByClassName("weissC6")[0].innerHTML = springer1Schwarz;
    document.getElementsByClassName("weissC6")[0].style.color = "#65d9f2";
    document.getElementsByClassName("weissG1")[0].innerHTML = springer2Weiss;
    document.getElementsByClassName("weissG1")[0].style.color = "white";
    document.getElementsByClassName("weissG8")[0].innerHTML = springer2Schwarz;
    document.getElementsByClassName("weissG8")[0].style.color = "#65d9f2";
    document.getElementsByClassName("weissA1")[0].innerHTML = turm1Weiss;
    document.getElementsByClassName("weissA1")[0].style.color = "white";
    document.getElementsByClassName("weissA8")[0].innerHTML = turm1Schwarz;
    document.getElementsByClassName("weissA8")[0].style.color = "#65d9f2";
    document.getElementsByClassName("weissH1")[0].innerHTML = turm2Weiss;
    document.getElementsByClassName("weissH1")[0].style.color = "white";
    document.getElementsByClassName("weissH8")[0].innerHTML = turm2Schwarz;
    document.getElementsByClassName("weissH8")[0].style.color = "#65d9f2";
    document.getElementsByClassName("weissA2")[0].innerHTML = bauer1Weiss;
    document.getElementsByClassName("weissB2")[0].innerHTML = bauer2Weiss;
    document.getElementsByClassName("weissC2")[0].innerHTML = bauer3Weiss;
    document.getElementsByClassName("weissD2")[0].innerHTML = bauer4Weiss;
    document.getElementsByClassName("weissE4")[0].innerHTML = bauer5Weiss;
    document.getElementsByClassName("weissF2")[0].innerHTML = bauer6Weiss;
    document.getElementsByClassName("weissG2")[0].innerHTML = bauer7Weiss;
    document.getElementsByClassName("weissH2")[0].innerHTML = bauer8Weiss;
    document.getElementsByClassName("weissA2")[0].style.color = "white";
    document.getElementsByClassName("weissB2")[0].style.color = "white";
    document.getElementsByClassName("weissC2")[0].style.color = "white";
    document.getElementsByClassName("weissD2")[0].style.color = "white";
    document.getElementsByClassName("weissE4")[0].style.color = "white";
    document.getElementsByClassName("weissF2")[0].style.color = "white";
    document.getElementsByClassName("weissG2")[0].style.color = "white";
    document.getElementsByClassName("weissH2")[0].style.color = "white";
    document.getElementsByClassName("weissA7")[0].innerHTML = bauer1Schwarz;
    document.getElementsByClassName("weissB7")[0].innerHTML = bauer2Schwarz;
    document.getElementsByClassName("weissC7")[0].innerHTML = bauer3Schwarz;
    document.getElementsByClassName("weissD7")[0].innerHTML = bauer4Schwarz;
    document.getElementsByClassName("weissE5")[0].innerHTML = bauer5Schwarz;
    //document.getElementsByClassName("weissF7")[0].innerHTML = bauer6Schwarz;
    document.getElementsByClassName("weissG7")[0].innerHTML = bauer7Schwarz;
    document.getElementsByClassName("weissH7")[0].innerHTML = bauer8Schwarz;
    document.getElementsByClassName("weissA7")[0].style.color = "#65d9f2";
    document.getElementsByClassName("weissB7")[0].style.color = "#65d9f2";
    document.getElementsByClassName("weissC7")[0].style.color = "#65d9f2";
    document.getElementsByClassName("weissD7")[0].style.color = "#65d9f2";
    document.getElementsByClassName("weissE5")[0].style.color = "#65d9f2";
    //document.getElementsByClassName("weissF7")[0].style.color = "#65d9f2";
    document.getElementsByClassName("weissG7")[0].style.color = "#65d9f2";
    document.getElementsByClassName("weissH7")[0].style.color = "#65d9f2";
</script>

</body>
</html>
