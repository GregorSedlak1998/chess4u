<?php
session_start();
include("User.php");
$x = new User;


if($x -> IsLoggedIn())
    $logined_id = $_SESSION["username"];
else
    header('Location: index.php');

$pw="";
$userdb="root";
$server="localhost";
$db="chess4u";
$charset="utf8";
$opt=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];

$connection = new PDO("mysql: host=$server; dbname=$db; charset=$charset",$userdb,$pw,$opt);
if(!$connection)
{
    error_log("Error!");
    die("Datenbankfehler");
}
$statement1 = $connection->prepare("SELECT * FROM `spieler` WHERE id=:id");
$statement1->bindParam(':id',$logined_id,PDO::PARAM_STR);
$statement1->execute();
while ($row1 = $statement1->fetch())
{
    extract($row1);
    $logined = $row1['nachname'];
}

?>
<!doctype html>
<html lang="de">
<head>
    <title>chess4u -
    <?php
            echo $logined;
    ?>
    </title>

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="shortcut icon" href="http://chess4u.at/img/favicon.ico" type="image/x-icon">
    <link rel="icon" href="http://chess4u.at/img/favicon.ico" type="image/x-icon">

    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.css">
    <link rel="stylesheet" href="css2/style.css">

    <link rel="stylesheet" href="css2/inc/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css2/inc/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css2/style2.css">
    <link rel="stylesheet" href="css2/meins.css">
    <link rel="stylesheet" href="css2/mobile.css">

</head>
<body>


<nav id="main-navbar" class="navbar navbar-default" role="navigation"> <!-- Classes: navbar-default, navbar-inverse, navbar-fixed-top, navbar-fixed-bottom, navbar-transparent. Note: If you use non-transparent navbar, set "height: 98px;" to #header -->
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand page-scroll" href="body">CHESS4U</a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                        <?php
                        echo $logined;
                        ?> <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu">
                        <form class="navbar-form" action="?page=log" method="POST">
                            <li class="text-center">
                                <label for=""><a id="dropdownLink" href="logout.php">Logout</a></label>
                            </li>
                        </form>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>



<div class="container" id="formDiv">
    <div class="row main">
        <div class="panel-heading">
            <div class="panel-title text-center">
                <h5>Wählen sie ein Spiel aus ..</h5>


                    <?php
                        $pw="";
                        $userdb="root";
                        $server="localhost";
                        $db="chess4u";
                        $charset="utf8";
                        $opt=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
                            PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];

                        $connection = new PDO("mysql: host=$server; dbname=$db; charset=$charset",$userdb,$pw,$opt);
                        if(!$connection)
                        {
                            error_log("Error!");
                            die("Datenbankfehler");
                        }
                        $statement = $connection->prepare("SELECT *, DATE_FORMAT(spielbeginn, '%d.%m.%Y %H:%i:%s') AS 'spieldatum' FROM `schachspiel` WHERE `spieler_weiß` = :sp OR `spieler_schwarz` = :sp");
                        //SELECT spieler.vorname, spieler.nachname, schachspiel.schachspiel_id FROM `schachspiel` JOIN spieler ON schachspiel.spieler_weiß = spieler.id WHERE `spieler_weiß` = 1 OR `spieler_schwarz` = 1
                        $statement->bindParam(':sp',$_SESSION["username"],PDO::PARAM_STR);
                        $statement->execute();

                        ?>

                        <table class="table table-bordered table-responsive table-striped">
                            <tr>
                                <th class="text-center">Spiel Nr.</th>
                                <th class="text-center">Gegner</th>
<!--                                <th>Spieler Weiß Nachname</th>-->
<!--                                <th class="text-center">Spieler Schwarz</th>-->
<!--                                <th>Spieler Schwarz Nachname</th>-->
                                <th class="text-center">Datum & Uhrzeit</th>
                            </tr>

                        <?php

                        while ($row = $statement->fetch())
                        {
                            extract($row);
                            $sid = $schachspiel_id;
                            $sdatum = $spieldatum;
                            $sw = $spieler_weiß;
                            $ss = $spieler_schwarz;


                            $swName = "";
                            $ssName = "";


                            if($sw == $_SESSION["username"])
                            {
                                $swName = "Ich";
                            }
                            else {
                                $pw="";
                                $userdb="root";
                                $server="localhost";
                                $db="chess4u";
                                $charset="utf8";
                                $opt=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
                                    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];

                                $connection = new PDO("mysql: host=$server; dbname=$db; charset=$charset",$userdb,$pw,$opt);
                                if(!$connection)
                                {
                                    error_log("Error!");
                                    die("Datenbankfehler");
                                }
                                $statementSW = $connection->prepare("SELECT `vorname`, `nachname` FROM `spieler` WHERE id = :sid");
                                $statementSW->bindParam(':sid',$sw,PDO::PARAM_STR);
                                $statementSW->execute();

                                while ($rowSW = $statementSW->fetch())
                                {
                                    extract($rowSW);

                                    $swName = $vorname." ".$nachname;
                                }
                            }

                            if($ss == $_SESSION["username"])
                            {
                                $ssName = "Ich";
                            }
                            else {
                                $pw="";
                                $userdb="root";
                                $server="localhost";
                                $db="chess4u";
                                $charset="utf8";
                                $opt=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
                                    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];

                                $connection = new PDO("mysql: host=$server; dbname=$db; charset=$charset",$userdb,$pw,$opt);
                                if(!$connection)
                                {
                                    error_log("Error!");
                                    die("Datenbankfehler");
                                }
                                $statementSS = $connection->prepare("SELECT `vorname`, `nachname` FROM `spieler` WHERE id = :sid");
                                $statementSS->bindParam(':sid',$ss,PDO::PARAM_STR);
                                $statementSS->execute();

                                while ($rowSS = $statementSS->fetch())
                                {
                                    extract($rowSS);

                                    $ssName = $vorname." ".$nachname;
                                }
                            }

                            $gegner = "";
                            if($swName == "Ich")
                                $gegner = $ssName;
                            else if($ssName = "Ich")
                                $gegner = $swName;

                        ?>


                            <tr class="trSchachspiel" id="<?php echo $schachspiel_id?>">
                                <td class="text-center"><?php echo $schachspiel_id?></td>
                                <td class="text-center"><?php echo $gegner?></td>
                                <td class="text-center"><?php echo $spieldatum?></td>
                            </tr>

                        <?php
                        }
                        ?>
                        </table>

            </div>
        </div>
    </div>
</div>

<script src="bower_components/jquery/dist/jquery.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.js"></script>
<script src="js2/script.js"></script>


<?php



?>
</body>
</html>