<html>
<head>
    <title>chess4u - spiel</title>

    <script src="js/spiel.js"></script>

    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body onload="init()">

<nav class="navbar navbar-default">
    <div class="container-fluid">

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <div class="navbar-left">
                <a href="#" class="navbar-brand">Chess4U</a>
            </div>

            <ul class="nav navbar-nav navbar-right">
                <li class="active"><a href="#">History</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Angemeldet als: <b>Lewitsch</b><span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <form class="navbar-form" action="" method="POST">
                            <li>
                                <div class="form-group">
                                    <label class="sr-only" for="exampleInputEmail3">Email address</label>
                                    <input type="email" class="form-control" id="inputEmailLogin" name="inputEmailLogin" placeholder="Email">
                                </div>
                            </li>
                            <li role="separator" class="divider"></li>
                            <li>
                                <div class="form-group">
                                    <label class="sr-only" for="exampleInputPassword3">Password</label>
                                    <input type="password" class="form-control" id="inputPasswortLogin" name="inputPasswortLogin" placeholder="Password">
                                </div>
                            </li>
                            <li role="separator" class="divider"></li>
                            <li>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox"> Remember me
                                    </label>
                                </div>
                            </li>
                            <li role="separator" class="divider"></li>
                            <li>
                                <button type="submit" class="btn btn-default">Sign in</button>
                            </li>
                            <li role="separator" class="divider"></li>
                            <li>
                                <label for="">Passwort vergessen?</label>
                            </li>
                        </form>
                    </ul>
                </li>

            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>

<div class="container" id="formDiv">
    <div id="divAll" class="container col-md-12">
        <div style="padding-left: 50px;" class="container col-md-4">
            <h2 class="text-center">Partie 1</h2><br>
            <?php
            function runMyFunction() {
                shell_exec("sudo python /Users/raphael/Documents/Schule/Diplomarbeit/pr1/senddata.py");
            }

            if (isset($_GET['spiel'])) {
                runMyFunction();
            }
            ?>
            <a href='spiel_copy.php?spiel=start'>Spiel Starten</a>
            <h4>Gegner: Kirchknopf</h4>
            <h4>Sieger: Lewitsch (<span class="glyphicon glyphicon-user"></span>)</h4>

            <br><br>

            <ul>
                <li><a href="#kNotationTables" aria-controls="kNotationTables" role="tab" data-toggle="tab">Kurze Notation</a></li>
                <li><a href="#lNotationTables" aria-controls="lNotationTables" role="tab" data-toggle="tab">Lange Notation</a></li>
            </ul>
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane" id="kNotationTables">
                <table id="kNotationsTableW" class="table table-striped table-responsive table-bordered">
                    <tr>
                        <th class="text-center">NR</th>
                        <th class="text-center">Lewitsch (<span class="glyphicon glyphicon-user"></span>)</th>
                    </tr>
                </table>
                <table id="kNotationsTableS" class="table table-striped table-responsive table-bordered">
                    <tr>

                        <th class="text-center">NR</th>
                        <th class="text-center">Kirchknopf</th>
                    </tr>
                </table>
            </div>
                <div role="tabpanel" class="tab-pane" id="lNotationTables">
                <table id="lNotationsTableW" class="table table-striped table-responsive table-bordered">
                    <tr>
                        <th class="text-center">NR</th>
                        <th class="text-center">Lewitsch (<span class="glyphicon glyphicon-user"></span>)</th>
                    </tr>
                </table>
                <table id="lNotationsTableS" class="table table-striped table-responsive table-bordered">
                    <tr>

                        <th class="text-center">NR</th>
                        <th class="text-center">Kirchknopf</th>
                    </tr>
                </table>
            </div>
            </div>

            <button class="btn btn-default" type="submit">Drucken</button>
        </div>
        <div id="divWeiss" class="container col-md-5 col-md-offset-2">
            <table id="schachbrettWeiss">
                <tr>
                    <th class="text-center"></th>
                    <th class="text-center">A</th>
                    <th class="text-center">B</th>
                    <th class="text-center">C</th>
                    <th class="text-center">D</th>
                    <th class="text-center">E</th>
                    <th class="text-center">F</th>
                    <th class="text-center">G</th>
                    <th class="text-center">H</th>
                    <th class="text-center"></th>
                </tr>
                <?php
                include('brettWeiss.php');
                ?>
                <tr>
                    <th class="text-center"></th>
                    <th class="text-center">A</th>
                    <th class="text-center">B</th>
                    <th class="text-center">C</th>
                    <th class="text-center">D</th>
                    <th class="text-center">E</th>
                    <th class="text-center">F</th>
                    <th class="text-center">G</th>
                    <th class="text-center">H</th>
                    <th class="text-center"></th>
                </tr>
            </table>
        </div>
    </div>
</div>

<script src="bower_components/jquery/dist/jquery.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.js"></script>
<script src="js/meins.js"></script>

</body>
</html>
