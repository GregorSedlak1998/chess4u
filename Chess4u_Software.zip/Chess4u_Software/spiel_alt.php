<!doctype html>
<html lang="de">
<head>

    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Spiel</title>
    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.css">
    <link rel="stylesheet" href="css2/style.css">


</head>
<body>

<div id="zeitStopp">

    <button onclick="window.clearTimeout(hTimer);">stop</button>
    <!--            <div id="outID"></div>-->
    <!--            <div id="outID2"></div>-->
    <!--            <div id="outID3"></div>-->
</div>

<div id="divAll" class="container col-md-12">
    <div id="divWeiss" class="container col-md-6">
        <div class="container col-md-9">
            <table id="schachbrettWeiss">
                <tr>
                    <th class="text-center"></th>
                    <th class="text-center">A</th>
                    <th class="text-center">B</th>
                    <th class="text-center">C</th>
                    <th class="text-center">D</th>
                    <th class="text-center">E</th>
                    <th class="text-center">F</th>
                    <th class="text-center">G</th>
                    <th class="text-center">H</th>
                    <th class="text-center"></th>
                </tr>
                <?php
                include('brettWeiss.php');
                ?>
                <tr>
                    <th class="text-center"></th>
                    <th class="text-center">A</th>
                    <th class="text-center">B</th>
                    <th class="text-center">C</th>
                    <th class="text-center">D</th>
                    <th class="text-center">E</th>
                    <th class="text-center">F</th>
                    <th class="text-center">G</th>
                    <th class="text-center">H</th>
                    <th class="text-center"></th>
                </tr>
            </table>
        </div>

        <div id="divTabelleWeiss" class="container col-md-3">
            <table id="tabelleWeiss" class="table table-responsive text-center">
                <tr>
                    <th>Nr.</th>
                    <th>Spieler 1 - weiß</th>
                </tr>
                <tr>
                    <td></td>
                    <th class="text-center">Otto</th>
                </tr>
            </table>
        </div>
    </div>

    <div id="divSchw" class="container col-md-6">
        <div id="divTabelleSchwarz" class="container col-md-3">
            <table id="tabelleSchwarz" class="table table-responsive text-center">
                <tr>
                    <th>Nr.</th>
                    <th>Spieler 2 - schwarz</th>
                </tr>
                <tr>
                    <td></td>
                    <th class="text-center">Franz</th>
                </tr>
            </table>
        </div>

        <div class="container col-md-9">
            <table id="schachbrettSchwarz">
                <tr>
                    <th class="text-center"></th>
                    <th class="text-center">H</th>
                    <th class="text-center">G</th>
                    <th class="text-center">F</th>
                    <th class="text-center">E</th>
                    <th class="text-center">D</th>
                    <th class="text-center">C</th>
                    <th class="text-center">B</th>
                    <th class="text-center">A</th>
                    <th class="text-center"></th>
                </tr>
                <?php
                include('brettSchwarz.php');
                ?>
                <tr>
                    <th class="text-center"></th>
                    <th class="text-center">H</th>
                    <th class="text-center">G</th>
                    <th class="text-center">F</th>
                    <th class="text-center">E</th>
                    <th class="text-center">D</th>
                    <th class="text-center">C</th>
                    <th class="text-center">B</th>
                    <th class="text-center">A</th>
                    <th class="text-center"></th>
                </tr>
            </table>
        </div>
    </div>
</div>


<script src="bower_components/jquery/dist/jquery.js"></script>
<script src="js2/js.js"></script>

</body>
</html>