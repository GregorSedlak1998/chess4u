<?php
/**
 * Created by PhpStorm.
 * User: raphael
 * Date: 26.02.17
 * Time: 20:32
 */
session_start();
include("../ts1/User.php");
$x = new User;
?>

<html>
<head>
    <title>chess4u - logout</title>

    <link rel="shortcut icon" href="http://chess4u.at/img/favicon.ico" type="image/x-icon">
    <link rel="icon" href="http://chess4u.at/img/favicon.ico" type="image/x-icon">

    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="css/inc/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/inc/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style2.css">
    <link rel="stylesheet" href="css/meins.css">
    <link rel="stylesheet" href="css/mobile.css">
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container">

        <div class="navbar-header navbar-left">
            <a class="navbar-brand" href="#">Chess4U</a>
        </div>

    </div>
</nav>

<div class="container" id="formDiv">
    <div class="row main">
        <div class="panel-heading">
            <div class="panel-title text-center">
                <?php
                    if($x->logout())
                    {
                        ?><h5>Spiel beendet! <a class='color' href='../ts1/index.php'>einlogen?</a></h5><?php
                    }
                ?>
            </div>
        </div>
    </div>
</div>

<script src="bower_components/jquery/dist/jquery.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.js"></script>


<?php



?>
</body>
</html>
