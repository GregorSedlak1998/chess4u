<script>
    function init() {
        var host = "ws://localhost:8080";
        try {
            socket = new WebSocket(host);
            socket.onmessage = function (msg) {
                var altesFeld = msg.data.substr(0, 2);
                var feld = msg.data.substr(3, 2);
                var figur = msg.data.substr(6, 8);
                var farbe = msg.data.substr(6, 1);
                var figurGenau = msg.data.substr(7, 1);
                addNotationsListe(altesFeld, feld, farbe, figurGenau);
                for (var i = 8; i >= 1; i--) {
                    var abc = 'ABCDEFGH';
                    for (var j = 0; j < abc.length; j++) {
                        var feldx = '' + abc[j] + '' + i;
                        if (altesFeld == feldx) {
                            altePosition(altesFeld);
                        }
                        if (feld == feldx) {
                            welchePosition(feld, figur);
                        }
                    }
                }
            };
        }
        catch (ex) {
            log(ex);
        }
    }
</script>

<table id="schachbrettWeiss">
    <tr>
        <th class="text-center"></th>
        <th class="text-center">A</th>
        <th class="text-center">B</th>
        <th class="text-center">C</th>
        <th class="text-center">D</th>
        <th class="text-center">E</th>
        <th class="text-center">F</th>
        <th class="text-center">G</th>
        <th class="text-center">H</th>
        <th class="text-center"></th>
    </tr>
    <?php
    for ($i = 8; $i >= 1; $i--) {
        ?>
        <tr>
            <th class="text-center"><?= $i ?></th>
            <?php
            for ($j = "A"; $j <= "H"; $j++) {
                $farbeHintergrund = "black";
                if ($j == "B" || $j == "D" || $j == "F" || $j == "H") {
                    if ($i % 2 != 0) {
                        $farbeHintergrund = "white";
                    } else {
                        $farbeHintergrund = "#2b3336";
                    }
                } else if ($j == "A" || $j == "C" || $j == "E" || $j == "G") {
                    if ($i % 2 == 0) {
                        $farbeHintergrund = "white";
                    } else {
                        $farbeHintergrund = "#2b3336";
                    }
                }
                $tdId = "weiss" . $j . $i;
                ?>
                <td class="<?= $tdId ?>" style='background-color: <?= $farbeHintergrund ?>; text-align: center;'></td>
                <?php
            }
            ?>
            <th class="text-center"><?= $i ?></th>
        </tr>
        <?php
    }
    ?>
    <tr>
        <th class="text-center"></th>
        <th class="text-center">A</th>
        <th class="text-center">B</th>
        <th class="text-center">C</th>
        <th class="text-center">D</th>
        <th class="text-center">E</th>
        <th class="text-center">F</th>
        <th class="text-center">G</th>
        <th class="text-center">H</th>
        <th class="text-center"></th>
    </tr>
</table>