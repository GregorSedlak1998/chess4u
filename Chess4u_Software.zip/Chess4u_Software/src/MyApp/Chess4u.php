<?php
namespace MyApp;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use PDO;

class Chess4u implements MessageComponentInterface {
    protected $clients;
    private $dbh;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
    }

    public function onOpen(ConnectionInterface $conn) {
        // Store the new connection to send messages to later
        $this->clients->attach($conn);

        echo "New connection! ({$conn->resourceId})\n";
        echo $this->spiel_id;
    }

    public function onMessage(ConnectionInterface $from, $msg)
    {
        $numRecv = count($this->clients) - 1;
        echo sprintf('Connection %d sending message "%s" to %d other connection%s' . "\n"
            , $from->resourceId, $msg, $numRecv, $numRecv == 1 ? '' : 's');

        if ($this->saveMessage($msg)) {

            echo 'Saved message to DB';

        } else {

            echo '!';

        }

        foreach ($this->clients as $client) {
            if ($from !== $client) {
                // The sender is not the receiver, send to each client connected
                $client->send($msg);
            }
        }
    }

    public function onClose(ConnectionInterface $conn) {
        // The connection is closed, remove it, as we can no longer send it messages
        $this->clients->detach($conn);

        echo "Connection {$conn->resourceId} has disconnected\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";

        $conn->close();
    }

    public function whatFigur($feld)
    {
        if($feld == 'WK1')	$figur=1;
        //else if($feld == '04AA615A6D3B80') $figur=3;
        else if($feld == 'WD1')	$figur=2;
        //else if($feld == '76CA0424') //A1, C5, F5, E5, G1, B1, B5, E1, F1, C1, A5, D1, D5
            //$figur=2;
        else if($feld == 'SK1')	$figur=3;
        else if($feld == 'SD1')	$figur=4;
        else if($feld == 'WL1')	$figur=5;
        else if($feld == 'WL2')	$figur=6;
        else if($feld == 'WS1')	$figur=7;
        else if($feld == 'WS2')	$figur=8;
        else if($feld == 'WT1')	$figur=9;
        else if($feld == 'WT2')	$figur=10;
        else if($feld == 'WB1')	$figur=11;
        else if($feld == 'WB2')	$figur=12;
        else if($feld == 'WB3')	$figur=13;
        else if($feld == 'WB4')	$figur=14;
        else if($feld == 'WB5')	$figur=15;
        else if($feld == 'WB6')	$figur=16;
        else if($feld == 'WB7')	$figur=17;
        else if($feld == 'WB8')	$figur=18;
        else if($feld == 'SL1')	$figur=19;
        else if($feld == 'SL2')	$figur=20;
        else if($feld == 'SS1')	$figur=21;
        else if($feld == 'SS2')	$figur=22;
        else if($feld == 'ST1')	$figur=23;
        else if($feld == 'ST2')	$figur=24;
        else if($feld == 'SB1')	$figur=25;
        else if($feld == 'SB2')	$figur=26;
        else if($feld == 'SB3')	$figur=27;
        else if($feld == 'SB4')	$figur=28;
        else if($feld == 'SB5')	$figur=29;
        else if($feld == 'SB6')	$figur=30;
        else if($feld == 'SB7')	$figur=31;
        else if($feld == 'SB8')	$figur=32;
        return $figur;
    }
    /*public function whichFirstAltesFeld($neuesFeld, $altesFeld, $figur) {//wegGeben ..
        if($neuesFeld == 'E3' && substr($figur, 0,2) == 'WB')//c3, e3, d4, h5, d6, f6, e5
        {
            return 'E2';
        }
        else if($neuesFeld == 'C3' && substr($figur, 0,2) == 'WB')
        {
            return 'C2';
        }
        else if($neuesFeld == 'D4' && $altesFeld != 'D3' && substr($figur, 0,2) == 'WB')
        {
            return 'D2';
        }
        else if($neuesFeld == 'H5' && $altesFeld != 'H6' && substr($figur, 0,2) == 'SB')
        {
            return 'H7';
        }
        else if($neuesFeld == 'D6' && substr($figur, 0,2) == 'SB')
        {
            return 'D7';
        }
        else if($neuesFeld == 'F6' && substr($figur, 0,2) == 'SB')
        {
            return 'F7';
        }
        else if($neuesFeld == 'E5' && $altesFeld != 'E6' && substr($figur, 0,2) == 'SB')
        {
            return 'E7';
        }
        else {
            return $altesFeld;
        }
    }*/

    public function saveMessage($msg)
    {

        $data = json_decode($msg);

        if($msg == "newGame" || $msg == "spielende" || substr($msg, 0,3) == 'af:')
        {
            echo "newGame!! oder spielBeendet!!";
        }
        else
        {
            $altesFeld = substr($msg, 0,2);
            $feld = substr($msg,3,2);
            $figurMsg = substr($msg,6,3);//14, 8
            //echo $figurMsg;
            $figur = $this->whatFigur($figurMsg);
            //$altesFeld = $this->whichFirstAltesFeld($feld, $altesFeld_1, $figur);
            //echo $figur;
            if($altesFeld == '00')
            {
                $pw="";
                $user="root";
                $server="127.0.0.1";
                $db="chess4u";
                try {
                    $this->dbh = new PDO("mysql:host=$server; dbname=$db", $user, $pw);
                    $this->dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    echo 'Connected to Database<br/>';
                    $statement= $this->dbh->prepare("CALL chess4u.insertStartfelder(?,?);");
                    $statement->execute([$feld, $figur]);
                } catch (PDOException $ex) {
                    error_log("Error: ".$ex->getMessage());
                    die("Datenbankfehler");
                }
                return "fertig";
            }

            //$spielId = $this->spiel_id;
            //echo $spielId;
            //spielId = 1;
            $spielerWeiss = 1;
            $spielerSchwarz = 2;
            //$conversationId = $data->id;
            //$userId = $data->userId;
            $content = $data->content;

            //$db = new \mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

            $pw="";
            $user="root";
            $server="127.0.0.1";
            $db="chess4u";
            //$charset="utf8";
            //$opt=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
            //  PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];
            try {
                //$connect = new PDO("mysql: host=$server; dbname=$db; charset=$charset",$user,$pw,$opt);
                $this->dbh = new PDO("mysql:host=$server; dbname=$db", $user, $pw);
                $this->dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                //echo 'Connected to Database<br/>';
                $statement= $this->dbh->prepare("CALL chess4u.insertSpielzug(?,?,?)");
                $statement->execute([$altesFeld, $feld, $figur]);
                //$statement=$this->dbh->prepare("INSERT INTO `test`(`content`) VALUES (?)");
                //$statement->execute([$msg]);

            } catch (PDOException $ex) {
                error_log("Error: ".$ex->getMessage());
                die("Datenbankfehler");
            }

            /*$stmt = $db->prepare('
            INSERT INTO test
            (
            message
            )
            VALUES
            (
            ?
            )
            ');

            if($stmt)
            {

                $stmt->bind_param(
                    $content
                );

                $stmt->execute();

                $stmt->close();

                $db->close();

                return true;

            }
            else
            {

                return false;

            }*/
        }

    }
}