/**
 * Created by raphael on 28.10.16.
 */


var figurenObjBlack = {
    //figuren: ["K", "D", "L1", "L2", "S1", "S2", "T1", "T2", "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8"]
    figuren: ["<span class='glyphicon glyphicon-king'></span>",
        "<span class='glyphicon glyphicon-queen'></span>",
        "<span class='glyphicon glyphicon-pawn'></span>",
        "<span class='glyphicon glyphicon-knight'></span>",
        "<span class='glyphicon glyphicon-tower'></span>",
        "<span class='glyphicon glyphicon-bishop'></span>"]
};

var figurenObjWhite = {
    //figuren: ["K", "D", "L1", "L2", "S1", "S2", "T1", "T2", "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8"]
    figuren: ["<span class='glyphicon glyphicon-king'></span>",
        "<span class='glyphicon glyphicon-queen'></span>",
        "<span class='glyphicon glyphicon-pawn'></span>",
        "<span class='glyphicon glyphicon-knight'></span>",
        "<span class='glyphicon glyphicon-tower'></span>",
        "<span class='glyphicon glyphicon-bishop'></span>"]
};

figurenObjWhite.color = 'white';
figurenObjBlack.color = 'black';

//var figuren = ["K", "D", "L1", "L2", "S1", "S2", "T1", "T2", "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8"];
/*var koenigWeiss = figurenObjWhite.figuren[0];
var koenigSchwarz = figurenObjBlack.figuren[0];
var dameWeiss = figurenObjWhite.figuren[1];
var dameSchwarz = figurenObjBlack.figuren[1];
var laeufer1Weiss = figurenObjWhite.figuren[2];
var laeufer1Schwarz = figurenObjBlack.figuren[2];
var laeufer2Weiss = figurenObjWhite.figuren[3];
var laeufer2Schwarz = figurenObjBlack.figuren[3];
var springer1Weiss = figurenObjWhite.figuren[4];
var springer1Schwarz = figurenObjBlack.figuren[4];
var springer2Weiss = figurenObjWhite.figuren[5];
var springer2Schwarz = figurenObjBlack.figuren[5];
var turm1Weiss = figurenObjWhite.figuren[6];
var turm1Schwarz = figurenObjBlack.figuren[6];
var turm2Weiss = figurenObjWhite.figuren[7];
var turm2Schwarz = figurenObjBlack.figuren[7];
var bauer1Weiss = figurenObjWhite.figuren[8];
var bauer2Weiss = figurenObjWhite.figuren[9];
var bauer3Weiss = figurenObjWhite.figuren[10];
var bauer4Weiss = figurenObjWhite.figuren[11];
var bauer5Weiss = figurenObjWhite.figuren[12];
var bauer6Weiss = figurenObjWhite.figuren[13];
var bauer7Weiss = figurenObjWhite.figuren[14];
var bauer8Weiss = figurenObjWhite.figuren[15];
var bauer1Schwarz = figurenObjBlack.figuren[8];
var bauer2Schwarz = figurenObjBlack.figuren[9];
var bauer3Schwarz = figurenObjBlack.figuren[10];
var bauer4Schwarz = figurenObjBlack.figuren[11];
var bauer5Schwarz = figurenObjBlack.figuren[12];
var bauer6Schwarz = figurenObjBlack.figuren[13];
var bauer7Schwarz = figurenObjBlack.figuren[14];
var bauer8Schwarz = figurenObjBlack.figuren[15];*/
var koenigWeiss = figurenObjWhite.figuren[0];
var koenigSchwarz = figurenObjBlack.figuren[0];
var dameWeiss = figurenObjWhite.figuren[1];
var dameSchwarz = figurenObjBlack.figuren[1];
var laeufer1Weiss = figurenObjWhite.figuren[2];
var laeufer1Schwarz = figurenObjBlack.figuren[2];
var laeufer2Weiss = figurenObjWhite.figuren[2];
var laeufer2Schwarz = figurenObjBlack.figuren[2];
var springer1Weiss = figurenObjWhite.figuren[3];
var springer1Schwarz = figurenObjBlack.figuren[3];
var springer2Weiss = figurenObjWhite.figuren[3];
var springer2Schwarz = figurenObjBlack.figuren[3];
var turm1Weiss = figurenObjWhite.figuren[4];
var turm1Schwarz = figurenObjBlack.figuren[4];
var turm2Weiss = figurenObjWhite.figuren[4];
var turm2Schwarz = figurenObjBlack.figuren[4];
var bauer1Weiss = figurenObjWhite.figuren[5];
var bauer2Weiss = figurenObjWhite.figuren[5];
var bauer3Weiss = figurenObjWhite.figuren[5];
var bauer4Weiss = figurenObjWhite.figuren[5];
var bauer5Weiss = figurenObjWhite.figuren[5];
var bauer6Weiss = figurenObjWhite.figuren[5];
var bauer7Weiss = figurenObjWhite.figuren[5];
var bauer8Weiss = figurenObjWhite.figuren[5];
var bauer1Schwarz = figurenObjBlack.figuren[5];
var bauer2Schwarz = figurenObjBlack.figuren[5];
var bauer3Schwarz = figurenObjBlack.figuren[5];
var bauer4Schwarz = figurenObjBlack.figuren[5];
var bauer5Schwarz = figurenObjBlack.figuren[5];
var bauer6Schwarz = figurenObjBlack.figuren[5];
var bauer7Schwarz = figurenObjBlack.figuren[5];
var bauer8Schwarz = figurenObjBlack.figuren[5];
document.getElementsByClassName("weissE1")[0].innerHTML = koenigWeiss;
document.getElementsByClassName("weissE1")[0].style.color = "white";
document.getElementsByClassName("weissE8")[0].innerHTML = koenigSchwarz;
document.getElementsByClassName("weissE8")[0].style.color = "#65d9f2";
document.getElementsByClassName("weissD1")[0].innerHTML = dameWeiss;
document.getElementsByClassName("weissD1")[0].style.color = "white";
document.getElementsByClassName("weissD8")[0].innerHTML = dameSchwarz;
document.getElementsByClassName("weissD8")[0].style.color = "#65d9f2";
document.getElementsByClassName("weissC1")[0].innerHTML = laeufer1Weiss;
document.getElementsByClassName("weissC1")[0].style.color = "white";
document.getElementsByClassName("weissC8")[0].innerHTML = laeufer1Schwarz;
document.getElementsByClassName("weissC8")[0].style.color = "#65d9f2";
document.getElementsByClassName("weissF1")[0].innerHTML = laeufer2Weiss;
document.getElementsByClassName("weissF1")[0].style.color = "white";
document.getElementsByClassName("weissF8")[0].innerHTML = laeufer2Schwarz;
document.getElementsByClassName("weissF8")[0].style.color = "#65d9f2";
document.getElementsByClassName("weissB1")[0].innerHTML = springer1Weiss;
document.getElementsByClassName("weissB1")[0].style.color = "white";
document.getElementsByClassName("weissB8")[0].innerHTML = springer1Schwarz;
document.getElementsByClassName("weissB8")[0].style.color = "#65d9f2";
document.getElementsByClassName("weissG1")[0].innerHTML = springer2Weiss;
document.getElementsByClassName("weissG1")[0].style.color = "white";
document.getElementsByClassName("weissG8")[0].innerHTML = springer2Schwarz;
document.getElementsByClassName("weissG8")[0].style.color = "#65d9f2";
document.getElementsByClassName("weissA1")[0].innerHTML = turm1Weiss;
document.getElementsByClassName("weissA1")[0].style.color = "white";
document.getElementsByClassName("weissA8")[0].innerHTML = turm1Schwarz;
document.getElementsByClassName("weissA8")[0].style.color = "#65d9f2";
document.getElementsByClassName("weissH1")[0].innerHTML = turm2Weiss;
document.getElementsByClassName("weissH1")[0].style.color = "white";
document.getElementsByClassName("weissH8")[0].innerHTML = turm2Schwarz;
document.getElementsByClassName("weissH8")[0].style.color = "#65d9f2";
document.getElementsByClassName("weissA2")[0].innerHTML = bauer1Weiss;
document.getElementsByClassName("weissB2")[0].innerHTML = bauer2Weiss;
document.getElementsByClassName("weissC2")[0].innerHTML = bauer3Weiss;
document.getElementsByClassName("weissD2")[0].innerHTML = bauer4Weiss;
document.getElementsByClassName("weissE2")[0].innerHTML = bauer5Weiss;
document.getElementsByClassName("weissF2")[0].innerHTML = bauer6Weiss;
document.getElementsByClassName("weissG2")[0].innerHTML = bauer7Weiss;
document.getElementsByClassName("weissH2")[0].innerHTML = bauer8Weiss;
document.getElementsByClassName("weissA2")[0].style.color = "white";
document.getElementsByClassName("weissB2")[0].style.color = "white";
document.getElementsByClassName("weissC2")[0].style.color = "white";
document.getElementsByClassName("weissD2")[0].style.color = "white";
document.getElementsByClassName("weissE2")[0].style.color = "white";
document.getElementsByClassName("weissF2")[0].style.color = "white";
document.getElementsByClassName("weissG2")[0].style.color = "white";
document.getElementsByClassName("weissH2")[0].style.color = "white";
document.getElementsByClassName("weissA7")[0].innerHTML = bauer1Schwarz;
document.getElementsByClassName("weissB7")[0].innerHTML = bauer2Schwarz;
document.getElementsByClassName("weissC7")[0].innerHTML = bauer3Schwarz;
document.getElementsByClassName("weissD7")[0].innerHTML = bauer4Schwarz;
document.getElementsByClassName("weissE7")[0].innerHTML = bauer5Schwarz;
document.getElementsByClassName("weissF7")[0].innerHTML = bauer6Schwarz;
document.getElementsByClassName("weissG7")[0].innerHTML = bauer7Schwarz;
document.getElementsByClassName("weissH7")[0].innerHTML = bauer8Schwarz;
document.getElementsByClassName("weissA7")[0].style.color = "#65d9f2";
document.getElementsByClassName("weissB7")[0].style.color = "#65d9f2";
document.getElementsByClassName("weissC7")[0].style.color = "#65d9f2";
document.getElementsByClassName("weissD7")[0].style.color = "#65d9f2";
document.getElementsByClassName("weissE7")[0].style.color = "#65d9f2";
document.getElementsByClassName("weissF7")[0].style.color = "#65d9f2";
document.getElementsByClassName("weissG7")[0].style.color = "#65d9f2";
document.getElementsByClassName("weissH7")[0].style.color = "#65d9f2";

document.getElementsByClassName("schwE1")[0].innerHTML = koenigWeiss;
document.getElementsByClassName("schwE1")[0].style.color = "white";
document.getElementsByClassName("schwE8")[0].innerHTML = koenigSchwarz;
document.getElementsByClassName("schwE8")[0].style.color = "#65d9f2";
document.getElementsByClassName("schwD1")[0].innerHTML = dameWeiss;
document.getElementsByClassName("schwD1")[0].style.color = "white";
document.getElementsByClassName("schwD8")[0].innerHTML = dameSchwarz;
document.getElementsByClassName("schwD8")[0].style.color = "#65d9f2";
document.getElementsByClassName("schwC1")[0].innerHTML = laeufer1Weiss;
document.getElementsByClassName("schwC1")[0].style.color = "white";
document.getElementsByClassName("schwC8")[0].innerHTML = laeufer1Schwarz;
document.getElementsByClassName("schwC8")[0].style.color = "#65d9f2";
document.getElementsByClassName("schwF1")[0].innerHTML = laeufer2Weiss;
document.getElementsByClassName("schwF1")[0].style.color = "white";
document.getElementsByClassName("schwF8")[0].innerHTML = laeufer2Schwarz;
document.getElementsByClassName("schwF8")[0].style.color = "#65d9f2";
document.getElementsByClassName("schwB1")[0].innerHTML = springer1Weiss;
document.getElementsByClassName("schwB1")[0].style.color = "white";
document.getElementsByClassName("schwB8")[0].innerHTML = springer1Schwarz;
document.getElementsByClassName("schwB8")[0].style.color = "#65d9f2";
document.getElementsByClassName("schwG1")[0].innerHTML = springer2Weiss;
document.getElementsByClassName("schwG1")[0].style.color = "white";
document.getElementsByClassName("schwG8")[0].innerHTML = springer2Schwarz;
document.getElementsByClassName("schwG8")[0].style.color = "#65d9f2";
document.getElementsByClassName("schwA1")[0].innerHTML = turm1Weiss;
document.getElementsByClassName("schwA1")[0].style.color = "white";
document.getElementsByClassName("schwA8")[0].innerHTML = turm1Schwarz;
document.getElementsByClassName("schwA8")[0].style.color = "#65d9f2";
document.getElementsByClassName("schwH1")[0].innerHTML = turm2Weiss;
document.getElementsByClassName("schwH1")[0].style.color = "white";
document.getElementsByClassName("schwH8")[0].innerHTML = turm2Schwarz;
document.getElementsByClassName("schwH8")[0].style.color = "#65d9f2";
document.getElementsByClassName("schwA2")[0].innerHTML = bauer1Weiss;
document.getElementsByClassName("schwB2")[0].innerHTML = bauer2Weiss;
document.getElementsByClassName("schwC2")[0].innerHTML = bauer3Weiss;
document.getElementsByClassName("schwD2")[0].innerHTML = bauer4Weiss;
document.getElementsByClassName("schwE2")[0].innerHTML = bauer5Weiss;
document.getElementsByClassName("schwF2")[0].innerHTML = bauer6Weiss;
document.getElementsByClassName("schwG2")[0].innerHTML = bauer7Weiss;
document.getElementsByClassName("schwH2")[0].innerHTML = bauer8Weiss;
document.getElementsByClassName("schwA2")[0].style.color = "white";
document.getElementsByClassName("schwB2")[0].style.color = "white";
document.getElementsByClassName("schwC2")[0].style.color = "white";
document.getElementsByClassName("schwD2")[0].style.color = "white";
document.getElementsByClassName("schwE2")[0].style.color = "white";
document.getElementsByClassName("schwF2")[0].style.color = "white";
document.getElementsByClassName("schwG2")[0].style.color = "white";
document.getElementsByClassName("schwH2")[0].style.color = "white";
document.getElementsByClassName("schwA7")[0].innerHTML = bauer1Schwarz;
document.getElementsByClassName("schwB7")[0].innerHTML = bauer2Schwarz;
document.getElementsByClassName("schwC7")[0].innerHTML = bauer3Schwarz;
document.getElementsByClassName("schwD7")[0].innerHTML = bauer4Schwarz;
document.getElementsByClassName("schwE7")[0].innerHTML = bauer5Schwarz;
document.getElementsByClassName("schwF7")[0].innerHTML = bauer6Schwarz;
document.getElementsByClassName("schwG7")[0].innerHTML = bauer7Schwarz;
document.getElementsByClassName("schwH7")[0].innerHTML = bauer8Schwarz;
document.getElementsByClassName("schwA7")[0].style.color = "#65d9f2";
document.getElementsByClassName("schwB7")[0].style.color = "#65d9f2";
document.getElementsByClassName("schwC7")[0].style.color = "#65d9f2";
document.getElementsByClassName("schwD7")[0].style.color = "#65d9f2";
document.getElementsByClassName("schwE7")[0].style.color = "#65d9f2";
document.getElementsByClassName("schwF7")[0].style.color = "#65d9f2";
document.getElementsByClassName("schwG7")[0].style.color = "#65d9f2";
document.getElementsByClassName("schwH7")[0].style.color = "#65d9f2";
/*    var koenigWeiss = document.getElementsByClassName("E1")[0].innerHTML = figuren[0];
    var koenigSchwarz = document.getElementsByClassName("E8")[0].innerHTML = figuren[0];
    var dameWeiss = document.getElementsByClassName("D1")[0].innerHTML = figuren[1];
    var dameSchwarz = document.getElementsByClassName("D8")[0].innerHTML = figuren[1];
    var laeufer1Weiss = document.getElementsByClassName("C1")[0].innerHTML = figuren[2];
    var laeufer1Schwarz = document.getElementsByClassName("C8")[0].innerHTML = figuren[2];
    var laeufer2Weiss = document.getElementsByClassName("F1")[0].innerHTML = figuren[3];
    var laeufer2Schwarz = document.getElementsByClassName("F8")[0].innerHTML = figuren[3];
    var springer1Weiss = document.getElementsByClassName("B1")[0].innerHTML = figuren[4];
    var springer1Schwarz = document.getElementsByClassName("B8")[0].innerHTML = figuren[4];
    var springer2Weiss = document.getElementsByClassName("G1")[0].innerHTML = figuren[5];
    var springer2Schwarz = document.getElementsByClassName("G8")[0].innerHTML = figuren[5];
    var turm1Weiss = document.getElementsByClassName("A1")[0].innerHTML = figuren[6];
    var turm1Schwarz = document.getElementsByClassName("A8")[0].innerHTML = figuren[6];
    var turm2Weiss = document.getElementsByClassName("H1")[0].innerHTML = figuren[7];
    var turm2Schwarz = document.getElementsByClassName("H8")[0].innerHTML = figuren[7];
    var bauer1Weiss = document.getElementsByClassName("A2")[0].innerHTML = figuren[8];
    var bauer2Weiss = document.getElementsByClassName("B2")[0].innerHTML = figuren[9];
    var bauer3Weiss = document.getElementsByClassName("C2")[0].innerHTML = figuren[10];
    var bauer4Weiss = document.getElementsByClassName("D2")[0].innerHTML = figuren[11];
    var bauer5Weiss = document.getElementsByClassName("E2")[0].innerHTML = figuren[12];
    var bauer6Weiss = document.getElementsByClassName("F2")[0].innerHTML = figuren[13];
    var bauer7Weiss = document.getElementsByClassName("G2")[0].innerHTML = figuren[14];
    var bauer8Weiss = document.getElementsByClassName("H2")[0].innerHTML = figuren[15];
    var bauer1Schwarz = document.getElementsByClassName("A7")[0].innerHTML = figuren[8];
    var bauer2Schwarz = document.getElementsByClassName("B7")[0].innerHTML = figuren[9];
    var bauer3Schwarz = document.getElementsByClassName("C7")[0].innerHTML = figuren[10];
    var bauer4Schwarz = document.getElementsByClassName("D7")[0].innerHTML = figuren[11];
    var bauer5Schwarz = document.getElementsByClassName("E7")[0].innerHTML = figuren[12];
    var bauer6Schwarz = document.getElementsByClassName("F7")[0].innerHTML = figuren[13];
    var bauer7Schwarz = document.getElementsByClassName("G7")[0].innerHTML = figuren[14];
    var bauer8Schwarz = document.getElementsByClassName("H7")[0].innerHTML = figuren[15];*/
    //console.log(koenigWeiss,koenigSchwarz,dameWeiss,dameSchwarz,laeufer1Weiss,laeufer1Schwarz,laeufer2Weiss,laeufer2Schwarz,springer1Weiss,springer1Schwarz,springer2Weiss,springer2Schwarz,turm1Weiss,turm1Schwarz,turm2Weiss,turm2Schwarz,bauer1Weiss,bauer1Schwarz,bauer2Weiss,bauer2Schwarz,bauer3Weiss,bauer3Schwarz,bauer4Weiss,bauer4Schwarz,bauer5Weiss,bauer5Schwarz,bauer6Weiss,bauer6Schwarz,bauer7Weiss,bauer7Schwarz,bauer8Weiss,bauer8Schwarz)


function startTimer(intCount){
    //document.getElementById("outID").innerHTML = intCount;
    var forW = (intCount+2)/4;
    var forB = intCount/4;
    //document.getElementById("outID2").innerHTML = forW;
    //document.getElementById("outID3").innerHTML = forB;

    if(intCount < 999)
        hTimer = window.setTimeout(function(){ startTimer(++intCount);}, 1000);

    if(intCount > 0 && intCount %2 == 0 && intCount %4 != 0)
    {
        /*
         var newTr = document.createElement("tr");
         var newTd = document.createElement("td");
         $("#tabelle").appendChild(newTr).appendChild(newTd);
         */

        //1:2,2:4,3:6,4:8,5:10

        var nr = intCount/2;
        var schachzuegeWeiss = ['f2-f4','f4xe5','e5xd6','g2-g3','g1-f3','h2xg3'];
        //var schachzuegeWeiss = ['f2-f4','f4xe5','e5xd6','g2-g3','Ng1-f3','h2xg3'];
        //var schachzuegeSchwarz = ['e7-e5','d7-d6','Bf8xd6','Qd8-g5','Qg5xg3+','Bd6xg3#'];
        //var schachzuege = ['f2-f4','e7-e5','f4xe5','d7-d6','e5xd6','Bf8xd6','g2-g3','Qd8-g5','Ng1-f3','Qg5xg3+','h2xg3','Bd6xg3#'];
        //console.log(schachzuegeWeiss);
        //console.log(schachzuegeSchwarz);

        //document.getElementById("tabelle").innerHTML += "<tr id='id_" + id + "'><td>" + nr + "</td><td></td><td></td><td></td></tr>";
        document.getElementById("tabelleWeiss").innerHTML += "<tr id='" + forW + "'><td>" + forW + "</td><td>" + schachzuegeWeiss[forW - 1] + "</td></tr>";

        //console.log("spalte hinzufuegen" + schachzuegeWeiss[nr] + schachzuegeSchwarz[nr]);
        //document.getElementById("tabelle").innerHTML += "<tr><td>" + nr + "</td><td>" + schachzuegeWeiss[nr - 1] + "</td><td>" + schachzuegeSchwarz[nr - 1] + "</td></tr>";

        //document.getElementById(nr).innerHTML += "<td>" + schachzuege[nr - 1] + "</td>";
        //document.getElementById("tabelle").innerHTML += "<td></td><td>" + schachzuege[nr - 1] + "</td><td></td><td></td>"


        if(forW == 1)
        {
            document.getElementsByClassName("weissF2")[0].innerHTML = "";
            document.getElementsByClassName("weissF4")[0].innerHTML = bauer6Weiss;
            document.getElementsByClassName("weissF4")[0].style.color = "white";
            document.getElementsByClassName("schwF2")[0].innerHTML = "";
            document.getElementsByClassName("schwF4")[0].innerHTML = bauer6Weiss;
            document.getElementsByClassName("schwF4")[0].style.color = "white";
            //document.getElementsByClassName("E7")[0].innerHTML = "";
            //document.getElementsByClassName("E5")[0].innerHTML = bauer5Schwarz;
            //document.getElementsByClassName("E5")[0].style.color = "black";
        }
        else if(forW == 2)
        {
            document.getElementsByClassName("weissF4")[0].innerHTML = "";
            document.getElementsByClassName("weissE5")[0].innerHTML = bauer6Weiss;
            document.getElementsByClassName("weissE5")[0].style.color = "white";
            document.getElementsByClassName("schwF4")[0].innerHTML = "";
            document.getElementsByClassName("schwE5")[0].innerHTML = bauer6Weiss;
            document.getElementsByClassName("schwE5")[0].style.color = "white";
            //document.getElementsByClassName("D7")[0].innerHTML = "";
            //document.getElementsByClassName("D6")[0].innerHTML = bauer4Schwarz;
            //document.getElementsByClassName("D6")[0].style.color = "black";
        }
        else if(forW == 3)
        {
            document.getElementsByClassName("weissE5")[0].innerHTML = "";
            document.getElementsByClassName("weissD6")[0].innerHTML = bauer6Weiss;
            document.getElementsByClassName("weissD6")[0].style.color = "white";
            document.getElementsByClassName("schwE5")[0].innerHTML = "";
            document.getElementsByClassName("schwD6")[0].innerHTML = bauer6Weiss;
            document.getElementsByClassName("schwD6")[0].style.color = "white";
            //document.getElementsByClassName("F8")[0].innerHTML = "";
            //document.getElementsByClassName("D6")[0].innerHTML = springer1Schwarz;
            //document.getElementsByClassName("D6")[0].style.color = "black";
        }
        else if(forW == 4)
        {
            document.getElementsByClassName("weissG2")[0].innerHTML = "";
            document.getElementsByClassName("weissG3")[0].innerHTML = bauer6Weiss;
            document.getElementsByClassName("weissG3")[0].style.color = "white";
            document.getElementsByClassName("schwG2")[0].innerHTML = "";
            document.getElementsByClassName("schwG3")[0].innerHTML = bauer6Weiss;
            document.getElementsByClassName("schwG3")[0].style.color = "white";
            //document.getElementsByClassName("D8")[0].innerHTML = "";
            //document.getElementsByClassName("G5")[0].innerHTML = dameSchwarz;
            //document.getElementsByClassName("G5")[0].style.color = "black";
        }
        else if(forW == 5)
        {
            document.getElementsByClassName("weissG1")[0].innerHTML = "";
            document.getElementsByClassName("weissF3")[0].innerHTML = springer2Weiss;
            document.getElementsByClassName("weissF3")[0].style.color = "white";
            document.getElementsByClassName("schwG1")[0].innerHTML = "";
            document.getElementsByClassName("schwF3")[0].innerHTML = springer2Weiss;
            document.getElementsByClassName("schwF3")[0].style.color = "white";
            //document.getElementsByClassName("G5")[0].innerHTML = "";
            //document.getElementsByClassName("G3")[0].innerHTML = dameSchwarz;
            //document.getElementsByClassName("G3")[0].style.color = "black";
            //document.getElementsByClassName("G3")[0].style.backgroundColor = "yellow";
            //document.getElementsByClassName("F2")[0].style.backgroundColor = "yellow";
            //document.getElementsByClassName("E1")[0].style.backgroundColor = "yellow";
        }
        else if(forW == 6)
        {
            document.getElementsByClassName("weissH2")[0].innerHTML = "";
            document.getElementsByClassName("weissG3")[0].innerHTML = bauer8Weiss;
            document.getElementsByClassName("weissG3")[0].style.color = "whitewhite";
            document.getElementsByClassName("weissG3")[0].style.backgroundColor = "#2b3336";
            document.getElementsByClassName("weissG3")[0].style.borderColor = "#2b3336";
            document.getElementsByClassName("weissF3")[0].style.borderColor = "#2b3336";
            document.getElementsByClassName("weissF2")[0].style.backgroundColor = "#2b3336";
            document.getElementsByClassName("weissF2")[0].style.borderColor = "#2b3336";
            document.getElementsByClassName("weissE2")[0].style.borderColor = "#2b3336";
            document.getElementsByClassName("weissE1")[0].style.backgroundColor = "#2b3336";
            document.getElementsByClassName("weissE1")[0].style.borderColor = "#2b3336";
            document.getElementsByClassName("weissD1")[0].style.borderColor = "#2b3336";
            document.getElementsByClassName("weissG4")[0].style.borderColor = "#2b3336";
            document.getElementsByClassName("schwH2")[0].innerHTML = "";
            document.getElementsByClassName("schwG3")[0].innerHTML = bauer8Weiss;
            document.getElementsByClassName("schwG3")[0].style.color = "whitewhite";
            document.getElementsByClassName("schwG3")[0].style.backgroundColor = "#2b3336";
            document.getElementsByClassName("schwG3")[0].style.borderColor = "#e5e9ea";
            document.getElementsByClassName("schwH3")[0].style.borderColor = "#e5e9ea";
            document.getElementsByClassName("schwF2")[0].style.backgroundColor = "#2b3336";
            document.getElementsByClassName("schwF2")[0].style.borderColor = "#e5e9ea";
            document.getElementsByClassName("schwG2")[0].style.borderColor = "#e5e9ea";
            document.getElementsByClassName("schwE1")[0].style.backgroundColor = "#2b3336";
            document.getElementsByClassName("schwE1")[0].style.borderColor = "#e5e9ea";
            document.getElementsByClassName("schwF1")[0].style.borderColor = "#e5e9ea";
            //document.getElementsByClassName("D6")[0].innerHTML = "";
            //document.getElementsByClassName("G3")[0].innerHTML = springer1Schwarz;
            //document.getElementsByClassName("G3")[0].style.color = "black";
            //document.getElementsByClassName("G3")[0].style.backgroundColor = "red";
            //document.getElementsByClassName("F2")[0].style.backgroundColor = "red";
            //document.getElementsByClassName("E1")[0].style.backgroundColor = "red";
            //alert("Spieler Schwarz gewinnt!");
            //window.clearTimeout(hTimer);
        }


    }
    else if(intCount > 0 && intCount%4 == 0)
    {
        nr2 = intCount/4;
        //var schachzuegeSchwarz = ['e7-e5','d7-d6','Bf8xd6','Qd8-g5','Qg5xg3+','Bd6xg3#'];
        var schachzuegeSchwarz = ['e7-e5','d7-d6','f8xd6','d8-g5','g5xg3+','d6xg3#'];
        //document.getElementById("tabelle").innerHTML += "<tr id='" + forB + "'><td>" + forB + "</td><td></td><td>" + schachzuegeSchwarz[forB - 1] + "</td></tr>";
        document.getElementById("tabelleSchwarz").innerHTML += "<tr id='" + forB + "'><td>" + forB + "</td><td>" + schachzuegeSchwarz[forB - 1] + "</td></tr>";
        if(forB == 1)
        {
            document.getElementsByClassName("weissE7")[0].innerHTML = "";
            document.getElementsByClassName("weissE5")[0].innerHTML = bauer5Schwarz;
            document.getElementsByClassName("weissE5")[0].style.color = "#65d9f2";
            document.getElementsByClassName("schwE7")[0].innerHTML = "";
            document.getElementsByClassName("schwE5")[0].innerHTML = bauer5Schwarz;
            document.getElementsByClassName("schwE5")[0].style.color = "#65d9f2";
        }
        else if(forB == 2)
        {
            document.getElementsByClassName("weissD7")[0].innerHTML = "";
            document.getElementsByClassName("weissD6")[0].innerHTML = bauer4Schwarz;
            document.getElementsByClassName("weissD6")[0].style.color = "#65d9f2";
            document.getElementsByClassName("schwD7")[0].innerHTML = "";
            document.getElementsByClassName("schwD6")[0].innerHTML = bauer4Schwarz;
            document.getElementsByClassName("schwD6")[0].style.color = "#65d9f2";
        }
        else if(forB == 3)
        {
            document.getElementsByClassName("weissF8")[0].innerHTML = "";
            document.getElementsByClassName("weissD6")[0].innerHTML = laeufer2Schwarz;
            document.getElementsByClassName("weissD6")[0].style.color = "#65d9f2";
            document.getElementsByClassName("schwF8")[0].innerHTML = "";
            document.getElementsByClassName("schwD6")[0].innerHTML = laeufer2Schwarz;
            document.getElementsByClassName("schwD6")[0].style.color = "#65d9f2";
        }
        else if(forB == 4)
        {
            document.getElementsByClassName("weissD8")[0].innerHTML = "";
            document.getElementsByClassName("weissG5")[0].innerHTML = dameSchwarz;
            document.getElementsByClassName("weissG5")[0].style.color = "#65d9f2";
            document.getElementsByClassName("schwD8")[0].innerHTML = "";
            document.getElementsByClassName("schwG5")[0].innerHTML = dameSchwarz;
            document.getElementsByClassName("schwG5")[0].style.color = "#65d9f2";
        }
        else if(forB == 5)
        {
            document.getElementsByClassName("weissG5")[0].innerHTML = "";
            document.getElementsByClassName("weissG3")[0].innerHTML = dameSchwarz;
            document.getElementsByClassName("weissG3")[0].style.color = "#65d9f2";
            document.getElementsByClassName("weissG3")[0].style.backgroundColor = "yellow";
            document.getElementsByClassName("weissG3")[0].style.borderColor = "yellow";
            document.getElementsByClassName("weissF3")[0].style.borderRightColor = "yellow";
            document.getElementsByClassName("weissF3")[0].style.borderBottomColor = "yellow";
            document.getElementsByClassName("weissF2")[0].style.backgroundColor = "yellow";
            document.getElementsByClassName("weissF2")[0].style.borderColor = "yellow";
            document.getElementsByClassName("weissE2")[0].style.borderRightColor = "yellow";
            document.getElementsByClassName("weissE2")[0].style.borderBottomColor = "yellow";
            document.getElementsByClassName("weissE1")[0].style.backgroundColor = "yellow";
            document.getElementsByClassName("weissE1")[0].style.borderColor = "yellow";
            document.getElementsByClassName("weissD1")[0].style.borderRightColor = "yellow";
            document.getElementsByClassName("weissG4")[0].style.borderBottomColor = "yellow";
            document.getElementsByClassName("schwG5")[0].innerHTML = "";
            document.getElementsByClassName("schwG3")[0].innerHTML = dameSchwarz;
            document.getElementsByClassName("schwG3")[0].style.color = "#65d9f2";
            document.getElementsByClassName("schwG3")[0].style.backgroundColor = "yellow";
            document.getElementsByClassName("schwG3")[0].style.borderColor = "yellow";
            document.getElementsByClassName("schwH3")[0].style.borderRightColor = "yellow";
            document.getElementsByClassName("schwF2")[0].style.backgroundColor = "yellow";
            document.getElementsByClassName("schwF2")[0].style.borderColor = "yellow";
            document.getElementsByClassName("schwG2")[0].style.borderRightColor = "yellow";
            document.getElementsByClassName("schwG2")[0].style.borderBottomColor = "yellow";
            document.getElementsByClassName("schwE1")[0].style.backgroundColor = "yellow";
            document.getElementsByClassName("schwE1")[0].style.borderColor = "yellow";
            document.getElementsByClassName("schwF1")[0].style.borderRightColor = "yellow";
            document.getElementsByClassName("schwF1")[0].style.borderBottomColor = "yellow";
        }
        else if(forB == 6)
        {
            document.getElementsByClassName("weissD6")[0].innerHTML = "";
            document.getElementsByClassName("weissG3")[0].innerHTML = springer1Schwarz;
            document.getElementsByClassName("weissG3")[0].style.color = "#65d9f2";
            document.getElementsByClassName("weissG3")[0].style.backgroundColor = "red";
            document.getElementsByClassName("weissG3")[0].style.borderColor = "red";
            document.getElementsByClassName("weissF3")[0].style.borderRightColor = "red";
            document.getElementsByClassName("weissF3")[0].style.borderBottomColor = "red";
            document.getElementsByClassName("weissF2")[0].style.backgroundColor = "red";
            document.getElementsByClassName("weissF2")[0].style.borderColor = "red";
            document.getElementsByClassName("weissE2")[0].style.borderRightColor = "red";
            document.getElementsByClassName("weissE2")[0].style.borderBottomColor = "red";
            document.getElementsByClassName("weissE1")[0].style.backgroundColor = "red";
            document.getElementsByClassName("weissE1")[0].style.borderColor = "red";
            document.getElementsByClassName("weissD1")[0].style.borderRightColor = "red";
            document.getElementsByClassName("weissG4")[0].style.borderBottomColor = "red";
            document.getElementsByClassName("schwD6")[0].innerHTML = "";
            document.getElementsByClassName("schwG3")[0].innerHTML = springer1Schwarz;
            document.getElementsByClassName("schwG3")[0].style.color = "#65d9f2";
            document.getElementsByClassName("schwG3")[0].style.backgroundColor = "red";
            document.getElementsByClassName("schwG3")[0].style.borderColor = "red";
            document.getElementsByClassName("schwH3")[0].style.borderRightColor = "red";
            document.getElementsByClassName("schwF2")[0].style.backgroundColor = "red";
            document.getElementsByClassName("schwF2")[0].style.borderColor = "red";
            document.getElementsByClassName("schwG2")[0].style.borderRightColor = "red";
            document.getElementsByClassName("schwG2")[0].style.borderBottomColor = "red";
            document.getElementsByClassName("schwE1")[0].style.backgroundColor = "red";
            document.getElementsByClassName("schwE1")[0].style.borderColor = "red";
            document.getElementsByClassName("schwF1")[0].style.borderRightColor = "red";
            document.getElementsByClassName("schwF1")[0].style.borderBottomColor = "red";

            alert("Spieler Schwarz gewinnt!");
            window.clearTimeout(hTimer);
        }
    }
}

function start_again() {
    startTimer()
}

startTimer(0);