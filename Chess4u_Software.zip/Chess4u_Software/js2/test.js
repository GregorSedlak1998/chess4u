/**
 * Created by raphael on 13.10.16.
 */


var hTimer = null;

(function () {




    function schachbrettZeichnen() {
        for (var i=8; i>=1; i--){
            var schachbrettTrElement = document.createElement("tr");
            //var schachbrettTr = $("#schachbrett").appendChild(schachbrettTrElement);
            var schachbrettTr = document.getElementById("schachbrett").appendChild(schachbrettTrElement);
            //console.log("tr");
            for (var j = 1; j <= 8; j++)
            {
                var schachbrettTdElement = document.createElement("td");
                var schachbrettTd = schachbrettTr.appendChild(schachbrettTdElement);
                //var schachbrettBuchstaben = ['a','b','c','d','e','f','g','h'];
                var schachbrettBuchstaben = ['A','B','C','D','E','F','G','H'];

                var tdText = document.createTextNode(schachbrettBuchstaben[j - 1] + "" + i);
                schachbrettTd.appendChild(tdText);
                var x = schachbrettTd.setAttribute("class","td")
                console.log(x);
                if (i%2 == 0 && j%2 == 0 || i%2 == 1 && j%2 == 1)
                {
                    schachbrettTd.style.backgroundColor = "lightblue";
                    schachbrettTd.style.color = "lightblue";
                    //console.log("td schwarz");
                }
                else
                {
                    schachbrettTd.style.backgroundColor = "white";
                    schachbrettTd.style.color = "white";
                    //console.log("td weiß");
                }

                var figuren = ["K","D","L1","L2","S1","S2","T1","T2","B1","B2","B3","B4","B5","B6","B7","B8"];
                var k = document.createTextNode("K");
                //document.getElementsByClassName("E2");
                //document.getElementsByClassName("E1").appendChild(figuren[0]);
                //document.getElementsByClassName("E1").appendChild(k);

                //document.getElementsByClassName("E1").style.color = "grey";
                //document.getElementsByClassName("E8").appendChild(figuren[0]);
                //document.getElementsByClassName("E8").style.color = "black";

            }

        }


    }


    function startTimer(intCount){
        document.getElementById("outID").innerHTML = intCount;

        if(intCount < 999)
            hTimer = window.setTimeout(function(){ startTimer(++intCount);}, 1000);

        if(intCount > 0 && intCount%3 == 0)
        {
            /*
             var newTr = document.createElement("tr");
             var newTd = document.createElement("td");
             $("#tabelle").appendChild(newTr).appendChild(newTd);
             */

            var nr = intCount/3;
            var schachzuegeWeiss = ['f2-f4','f4xe5','e5xd6','g2-g3','Ng1-f3','h2xg3'];
            var schachzuegeSchwarz = ['e7-e5','d7-d6','Bf8xd6','Qd8-g5','Qg5xg3+','Bd6xg3#'];
            //console.log(schachzuegeWeiss);
            //console.log(schachzuegeSchwarz);
            console.log("spalte hinzufuegen" + schachzuegeWeiss[nr] + schachzuegeSchwarz[nr]);
            document.getElementById("tabelle").innerHTML += "<tr><td>" + nr + "</td><td>" + schachzuegeWeiss[nr - 1] + "</td><td>" + nr + "</td><td>" + schachzuegeSchwarz[nr - 1] + "</td></tr>";


        }
    }

    startTimer(0);
    schachbrettZeichnen();

})();
