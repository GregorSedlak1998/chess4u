/**
 * Created by raphael on 03.03.17.
 */

$(".trSchachspiel").on("click", clickSchachspiel);

function clickSchachspiel(object) {
    var id = object.currentTarget.id;
    console.log(id);

    // header("Location: login2.php?sid=".id);
    var url = "login2.php?sid="+id;
    console.log(url);
    window.location.assign(url);
}

var l = $("#kNotationsTableW tr").length;
var html = "";
var html2 = "";
for (var i = 1; i < l; i++) {
    var j = $("#kNotationsTableW tr:eq(" + i +") td:eq(0)").text();
    var jW = $("#kNotationsTableW tr:eq(" + i +") td:eq(1)").text();
    var jS = $("#kNotationsTableS tr:eq(" + i +") td:eq(1)").text();

    var jW2 = $("#lNotationsTableW tr:eq(" + i +") td:eq(1)").text();
    var jS2 = $("#lNotationsTableS tr:eq(" + i +") td:eq(1)").text();

    html = html + "<tr><td class='text-center'>"+j+"</td><td class='text-center text-vertical-center'>"+jW+"</td><td class='text-center'>"+jS+"</td></tr>";
    html2 = html2 + "<tr><td class='text-center'>"+j+"</td><td class='text-center'>"+jW2+"</td><td class='text-center'>"+jS2+"</td></tr>";
}
$("#kNotationsTable").append(html);
$("#lNotationsTable").append(html2);

function startPositionen() {
    welchePositionW("A1","T");
    welchePositionW("A2","");
    welchePositionW("B1","S");
    welchePositionW("B2","");
    welchePositionW("C1","L");
    welchePositionW("C2","");
    welchePositionW("D1","D");
    welchePositionW("D2","");
    welchePositionW("E1","K");
    welchePositionW("E2","");
    welchePositionW("F1","L");
    welchePositionW("F2","");
    welchePositionW("G1","S");
    welchePositionW("G2","");
    welchePositionW("H1","T");
    welchePositionW("H2","");
    welchePositionS("A8","T");
    welchePositionS("A7","");
    welchePositionS("B8","S");
    welchePositionS("B7","");
    welchePositionS("C8","L");
    welchePositionS("C7","");
    welchePositionS("D8","D");
    welchePositionS("D7","");
    welchePositionS("E8","K");
    welchePositionS("E7","");
    welchePositionS("F8","L");
    welchePositionS("F7","");
    welchePositionS("G8","S");
    welchePositionS("G7","");
    welchePositionS("H8","T");
    welchePositionS("H7","");

    var ap = ['A8','B8','C8','D8','E8','F8','G8','H8','A7','B7','C7','D7','E7','F7','G7','H7','A6','B6','C6','D6','E6','F6','G6','H6','A5','B5','C5','D5','E5','F5','G5','H5','A4','B4','C4','D4','E4','F4','G4','H4','A3','B3','C3','D3','E3','F3','G3','H3','A2','B2','C2','D2','E2','F2','G2','H2','A1','B1','C1','D1','E1','F1','G1','H1'];
    var sp = ["A1","A2","B1","B2","C1","C2","D1","D2","E1","E2","F1","F2","G1","G2","H1","H2","A8","A7","B8","B7","C8","C7","D8","D7","E8","E7","F8","F7","G8","G7","H8","H7"];
    for(var k=0;k<sp.length;k++)
    {
        if(ap.indexOf(sp[k]) > -1)
        {
            var index = ap.indexOf(sp[k]);
            ap.splice(index, 1);
        }
    }
    for(var l=0;l<ap.length;l++)
    {
        altePosition(ap[l]);
        //console.log(ap[l]);
    }
}
startPositionen();

function welcheFigurW(figur) {
    if (figur == 'K')
    {
        return "<span border='1px solid black' style='color: #757778' class='glyphicon glyphicon-king'></span>";
    }
    else if (figur == 'D')
    {
        return "<span border='1px solid black' style='color: #757778' class='glyphicon glyphicon-queen'></span>";
    }
    else if (figur == 'L')
    {
        return "<span border='1px solid black' style='color: #757778' class='glyphicon glyphicon-pawn'></span>";
    }
    else if (figur == 'S')
    {
        return "<span border='1px solid black' style='color: #757778' class='glyphicon glyphicon-knight'></span>";
    }
    else if (figur == 'T')
    {
        return "<span border='1px solid black' style='color: #757778' class='glyphicon glyphicon-tower'></span>";
    }
    else if (figur == '')
    {
        return "<span border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop'></span>";
    }

}
function welcheFigurS(figur) {
    if (figur == 'K')
    {
        return "<span border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-king'></span>";
    }
    else if (figur == 'D')
    {
        return "<span border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-queen'></span>";
    }
    else if (figur == 'L')
    {
        return "<span border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-pawn'></span>";
    }
    else if (figur == 'S')
    {
        return "<span border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-knight'></span>";
    }
    else if (figur == 'T')
    {
        return "<span border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-tower'></span>";
    }
    else if (figur == '')
    {
        return "<span border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop'></span>";
    }
}

function welchePositionW(feld, figur) {
    $(".weiss"+feld)[0].innerHTML = welcheFigurW(figur);
}
function welchePositionS(feld, figur) {
    $(".weiss"+feld)[0].innerHTML = welcheFigurS(figur);
}


function altePosition(altesFeld) {
    $(".weiss"+altesFeld)[0].innerHTML = "";
}

function welcheAlteFigur(figur) {
    // "<span border='1px solid black' style='color: #757778' class='glyphicon glyphicon-king'></span>";
    // "<span border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-king'></span>";

    if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-queen"></span>')
    {
        $("#afwd").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-pawn"></span>')
    {
        $("#afwl1").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-pawn"></span>')
    {
        $("#afwl2").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-knight"></span>')
    {
        $("#afws1").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-knight"></span>')
    {
        $("#afws2").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-tower"></span>')
    {
        $("#afwt1").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-tower"></span>')
    {
        $("#afwt2").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afwb1").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afwb2").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afwb3").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afwb4").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afwb5").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afwb6").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afwb7").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afwb8").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-queen"></span>')
    {
        $("#afsd").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-pawn"></span>')
    {
        $("#afsl1").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-pawn"></span>')
    {
        $("#afsl2").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-knight"></span>')
    {
        $("#afss1").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-knight"></span>')
    {
        $("#afss2").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-tower"></span>')
    {
        $("#afst1").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-tower"></span>')
    {
        $("#afst2").removeClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afsb1").removeClass('afsFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afsb2").removeClass('afsFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afsb3").removeClass('afsFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afsb4").removeClass('afsFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afsb5").removeClass('afsFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afsb6").removeClass('afsFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afsb7").removeClass('afsFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afsb8").removeClass('afsFigur');
    }

}
function welcheAlteFigur2(figur) {
    // "<span border='1px solid black' style='color: #757778' class='glyphicon glyphicon-king'></span>";
    // "<span border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-king'></span>";

    if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-queen"></span>')
    {
        $("#afwd").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-pawn"></span>')
    {
        $("#afwl1").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-pawn"></span>')
    {
        $("#afwl2").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-knight"></span>')
    {
        $("#afws1").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-knight"></span>')
    {
        $("#afws2").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-tower"></span>')
    {
        $("#afwt1").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-tower"></span>')
    {
        $("#afwt2").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afwb1").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afwb2").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afwb3").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afwb4").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afwb5").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afwb6").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afwb7").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #757778" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afwb8").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-queen"></span>')
    {
        $("#afsd").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-pawn"></span>')
    {
        $("#afsl1").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-pawn"></span>')
    {
        $("#afsl2").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-knight"></span>')
    {
        $("#afss1").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-knight"></span>')
    {
        $("#afss2").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-tower"></span>')
    {
        $("#afst1").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-tower"></span>')
    {
        $("#afst2").addClass('afwFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afsb1").addClass('afsFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afsb2").addClass('afsFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afsb3").addClass('afsFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afsb4").addClass('afsFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afsb5").addClass('afsFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afsb6").addClass('afsFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afsb7").addClass('afsFigur');
    }
    else if (figur == '<span border="1px solid black" style="color: #65d9f2" class="glyphicon glyphicon-bishop"></span>')
    {
        $("#afsb8").addClass('afsFigur');
    }

}
/*var feld = "";
for(var i = 8; i>=1; i--)
{
    var abc = 'ABCDEFGH';
    for(var j=0;j<abc.length;j++)
    {
        var feldx = ''+abc[j]+''+i;
        //console.log(feldx);
        // if(altesFeld == feldx)
        // {
        //     altePosition(altesFeld);
        // }
        if(feld == feldx)
        {
            welchePosition(feld, figur);
            console.log(feld);
            console.log(figur);
        }
    }
}*/

//var wo = 0;
var anzahlSpielzuege = $("#kNotationsTableW tr").length - 1;
//console.log(anzahlSpielzuege);

for(var woo=1; woo <= anzahlSpielzuege; woo++)
{
    $("#kNotationsTable tr:eq("+ woo +")").hide();
    $("#lNotationsTable tr:eq("+ woo +")").hide();

    $("#kNotationsTableW tr:eq("+ woo +")").hide();
    $("#kNotationsTableS tr:eq("+ woo +")").hide();
    $("#lNotationsTableW tr:eq("+ woo +")").hide();
    $("#lNotationsTableS tr:eq("+ woo +")").hide();
}

function zugnummern(wo) {
    //console.log(wo);
    for(var i=1; i <= anzahlSpielzuege; i++)
    {
        woo = i;
        //console.log(woo);
        //console.log(i);
        if(i <= wo)
        {
            //console.log(i);
            $("#kNotationsTable tr:eq("+ woo +")").show();
            $("#lNotationsTable tr:eq("+ woo +")").show();

            $("#kNotationsTableW tr:eq("+ woo +")").show();
            $("#kNotationsTableS tr:eq("+ woo +")").show();
            $("#lNotationsTableW tr:eq("+ woo +")").show();
            $("#lNotationsTableS tr:eq("+ woo +")").show();

            var figurW = $("#lNotationsTableW tr:eq("+ woo +") .SFig").text();
            var altesfeldW = $("#lNotationsTableW tr:eq("+ woo +") .SAP").text();
            var feldW = $("#lNotationsTableW tr:eq("+ woo +") .SNP").text();
            altePosition(altesfeldW);
            welchePositionW(feldW,figurW);
            if ($("#lNotationsTableS tr:eq("+ woBissiS +")").text() != '') {
                var figurS = $("#lNotationsTableS tr:eq(" + woo + ") .SFig").text();
                var altesfeldS = $("#lNotationsTableS tr:eq(" + woo + ") .SAP").text();
                var feldS = $("#lNotationsTableS tr:eq(" + woo + ") .SNP").text();
                altePosition(altesfeldS);
                welchePositionS(feldS, figurS);
            }
        }
        if(i > wo)
        {
            //console.log(i);
            $("#kNotationsTable tr:eq("+ woo +")").hide();
            $("#lNotationsTable tr:eq("+ woo +")").hide();

            $("#kNotationsTableW tr:eq("+ woo +")").hide();
            $("#kNotationsTableS tr:eq("+ woo +")").hide();
            $("#lNotationsTableW tr:eq("+ woo +")").hide();
            $("#lNotationsTableS tr:eq("+ woo +")").hide();
        }
    }
}

var woBissi = 0;
var woBissiW = 0;
var woBissiS = 0;
var anzahlSpielzuegeBissi = ($("#kNotationsTableW tr").length - 1) + ($("#kNotationsTableS tr").length - 1);
console.log(anzahlSpielzuegeBissi);

var afW = [];
console.log(afW);
var afS = [];
console.log(afS);

function zugnummernBissiW(woBissi) {
    for(var i=1; i <= anzahlSpielzuege; i++)
    {
        woo=i;
            if(woo <= woBissi)
            {
                //console.log(i);
                $("#kNotationsTable tr:eq("+ woo +")").show();
                //$("#kNotationsTable tr:eq("+ woBissi +") td:eq(2)").text('');
                $("#lNotationsTable tr:eq("+ woo +")").show();
                //$("#lNotationsTable tr:eq("+ woBissi +") td:eq(2)").text('');

                $("#kNotationsTableW tr:eq("+ woo +")").show();
                $("#lNotationsTableW tr:eq("+ woo +")").show();

                var figurW = $("#lNotationsTableW tr:eq("+ woo +") .SFig").text();
                var feldW = $("#lNotationsTableW tr:eq("+ woo +") .SNP").text();
                var altesfeldW = $("#lNotationsTableW tr:eq("+ woo +") .SAP").text();
                //af.push($(".weiss"+altesfeldW)[0].innerHTML);
                //console.log(af);
                altePosition(altesfeldW);
                welchePositionW(feldW,figurW);
            }
            if(woo > woBissi)
            {
                //console.log(i);
                $("#kNotationsTable tr:eq("+ woo +")").hide();
                $("#lNotationsTable tr:eq("+ woo +")").hide();

                $("#kNotationsTableW tr:eq("+ woo +")").hide();
                $("#lNotationsTableW tr:eq("+ woo +")").hide();
            }
    }
}
function zugnummernBissiS(woBissi) {
    for(var i=1; i <= anzahlSpielzuege; i++)
    {
        woo=i;
        if(woo <= woBissi)
        {
            //console.log(i);
            $("#kNotationsTable tr:eq("+ woo +") td:eq(2)").text($("#kNotationsTableS tr:eq("+ woo +") td:eq(1)").text());
            $("#lNotationsTable tr:eq("+ woo +") td:eq(2)").text($("#lNotationsTableS tr:eq("+ woo +") td:eq(1)").text());

            $("#kNotationsTableS tr:eq("+ woo +")").show();
            $("#lNotationsTableS tr:eq("+ woo +")").show();
            var figurS = $("#lNotationsTableS tr:eq("+ woo +") .SFig").text();
            var altesfeldS = $("#lNotationsTableS tr:eq("+ woo +") .SAP").text();
            var feldS = $("#lNotationsTableS tr:eq("+ woo +") .SNP").text();
            altePosition(altesfeldS);
            welchePositionS(feldS,figurS);
        }
        if(woo > woBissi)
        {
            //console.log(i);
            $("#kNotationsTable tr:eq("+ woo +") td:eq(2)").text('');
            $("#lNotationsTable tr:eq("+ woo +") td:eq(2)").text('');

            $("#kNotationsTableS tr:eq("+ woo +")").hide();
            $("#lNotationsTableS tr:eq("+ woo +")").hide();
        }
    }
}


$("#schrittBissiWeiter").on("click", fSchrittBissiWeiter);
$("#schrittBissiZurueck").on("click", fSchrittBissiZurueck);
$("#schrittWeiter").on("click", fSchrittWeiter);
$("#schrittZurueck").on("click", fSchrittZurueck);
$("#schrittEnde").on("click", fSchrittEnde);
$("#schrittAnfang").on("click", fSchrittAnfang);

function fSchrittBissiWeiter() {
    if(woBissi < anzahlSpielzuegeBissi)
    {
        woBissi++;
        if(woBissi%2!=0)
        {
            woBissiW++;
            if(afW.length != anzahlSpielzuege)
            {
                var altesfeldW = $("#lNotationsTableW tr:eq("+ woBissiW +") .SNP").text();
                afW.push($(".weiss"+altesfeldW)[0].innerHTML);
                console.log(woBissiW);
                console.log(afW);
            }
            if(afW[woBissiW-1] != '')
            {
                welcheAlteFigur(afW[woBissiW-1]);
                console.log(afW[woBissiW-1]);
            }
            $("#kNotationsTable tr:eq("+ woBissiW +") td:eq(2)").text('');
            $("#lNotationsTable tr:eq("+ woBissiW +") td:eq(2)").text('');
            zugnummernBissiW(woBissiW);
        }
        else
        {
            woBissiS++;
            if(afS.length != anzahlSpielzuege)
            {
                var altesfeldS = $("#lNotationsTableS tr:eq("+ woBissiS +") .SNP").text();
                if ($("#lNotationsTableS tr:eq("+ woBissiS +")").text() != '') {
                    afS.push($(".weiss" + altesfeldS)[0].innerHTML);
                }
                console.log(afS);
            }
            if(afS[woBissiS-1] != '')
            {
                welcheAlteFigur(afW[woBissiS-1]);
                console.log(afS[woBissiS-1]);
            }
            zugnummernBissiS(woBissiS);
        }
    }
}
function fSchrittBissiZurueck() {
    if(woBissi > 0)
    {
        woBissi--;
        if(woBissi%2==0)
        {
            woBissiW--;
            zugnummernBissiW(woBissiW);
            var woo = woBissiW;
            woo++;
            var figurW = $("#lNotationsTableW tr:eq("+ woo +") .SFig").text();
            var feldW = $("#lNotationsTableW tr:eq("+ woo +") .SAP").text();
            var altesfeldW = $("#lNotationsTableW tr:eq("+ woo +") .SNP").text();
            $(".weiss"+altesfeldW)[0].innerHTML = afW[woo-1];

            console.log(woBissiW);
            if(afW[woBissiW] != '')
            {
                welcheAlteFigur2(afW[woBissiW]);
                //console.log(afW[woBissiW]);
            }

            console.log(afW);

            //altePosition(altesfeldW);
            welchePositionW(feldW,figurW);
        }
        else
        {
            woBissiS--;
            $("#kNotationsTable tr:eq("+ woBissiS +") td:eq(2)").text('');
            $("#lNotationsTable tr:eq("+ woBissiS +") td:eq(2)").text('');
            zugnummernBissiS(woBissiS);
            var woo = woBissiS;
            woo++;
            var figurS = $("#lNotationsTableS tr:eq("+ woo +") .SFig").text();
            var feldS = $("#lNotationsTableS tr:eq("+ woo +") .SAP").text();
            var altesfeldS = $("#lNotationsTableS tr:eq("+ woo +") .SNP").text();
            $(".weiss"+altesfeldS)[0].innerHTML = afS[woo-1];

            console.log(woBissiS);
            if(afS[woBissiS] != '')
            {
                welcheAlteFigur2(afW[woBissiS]);
                console.log(afS[woBissiS]);
            }

            console.log(afS);

            //altePosition(altesfeldS);
            welchePositionS(feldS,figurS);
        }
    }
}
function fSchrittWeiter() {

    fSchrittBissiWeiter();
    fSchrittBissiWeiter();
    /*var wo = Math.round(woBissi/2);
    if(wo < anzahlSpielzuege)
    {
        //console.log('-');
        //console.log(wo);
        //console.log(woBissi);
        woBissi += 2;
        woBissiW++;
        woBissiS++;
        var woo = Math.round(woBissi/2);

        if(afW.length != anzahlSpielzuege)
        {
            var altesfeldW = $("#lNotationsTableW tr:eq("+ woBissiW +") .SNP").text();
            afW.push($(".weiss"+altesfeldW)[0].innerHTML);
            console.log(afW);
        }
        if(afS.length != anzahlSpielzuege)
        {
            var altesfeldS = $("#lNotationsTableS tr:eq("+ woBissiS +") .SNP").text();
            if ($("#lNotationsTableS tr:eq("+ woBissiS +")").text() != '') {
                afS.push($(".weiss"+altesfeldS)[0].innerHTML);
            }
            console.log(afS);
        }

        if(afW[woBissiW-1] != '')
        {
            welcheAlteFigur(afW[woBissiW-1]);
            console.log(afW[woBissiW-1]);
        }
        if ($("#lNotationsTableS tr:eq("+ woBissiS +")").text() != '') {
            if (afS[woBissiS - 1] != '') {
                welcheAlteFigur(afW[woBissiS - 1]);
                console.log(afS[woBissiS - 1]);
            }
        }


        zugnummern(woo);
        //console.log(woo);
    }*/
}
function fSchrittZurueck() {
    fSchrittBissiZurueck();
    fSchrittBissiZurueck();
    /*var wo = Math.round(woBissi/2);
    if(wo > 0)
    {
        //wo--;
        woBissi -= 2;
        woBissiW--;
        woBissiS--;
        var woo = Math.round(woBissi/2);
        //console.log(woBissi);
        //console.log(wo);
        zugnummern(woo);
        woo++;
        //console.log(woo);
        var figurW = $("#lNotationsTableW tr:eq("+ woo +") .SFig").text();
        var feldW = $("#lNotationsTableW tr:eq("+ woo +") .SAP").text();
        var altesfeldW = $("#lNotationsTableW tr:eq("+ woo +") .SNP").text();
        $(".weiss"+altesfeldW)[0].innerHTML = afW[woo-1];
        //altePosition(altesfeldW);
        welchePositionW(feldW,figurW);
        var figurS = $("#lNotationsTableS tr:eq("+ woo +") .SFig").text();
        var feldS = $("#lNotationsTableS tr:eq("+ woo +") .SAP").text();
        var altesfeldS = $("#lNotationsTableS tr:eq("+ woo +") .SNP").text();
        if ($("#lNotationsTableS tr:eq("+ woo +")").text() != '') {
            $(".weiss" + altesfeldS)[0].innerHTML = afS[woo - 1];
        }

        if(afW[woBissiW] != '')
        {
            welcheAlteFigur2(afW[woBissiW]);
            //console.log(afW[woBissiW]);
        }
        if ($("#lNotationsTableS tr:eq("+ woBissi + 1 +")").text() != '') {
            if (afS[woBissiS] != '') {
                welcheAlteFigur2(afW[woBissiS]);
                console.log(afS[woBissiS]);
            }
        }

        //altePosition(altesfeldS);
        welchePositionS(feldS,figurS);
    }*/
}
function fSchrittAnfang() {
    //wo = 0;
    woBissi = 0;
    woBissiW = 0;
    woBissiS = 0;
    zugnummern(woBissi);
    startPositionen();

    $("#afs span").addClass('afsFigur');
    $("#afw span").addClass('afwFigur');
}
function fSchrittEnde() {

    for(var i=1; i<=anzahlSpielzuege; i++) {
        fSchrittBissiWeiter();
        fSchrittBissiWeiter();
    }
    //wo = anzahlSpielzuege;
    /*woBissi = anzahlSpielzuegeBissi;
    woBissiW = anzahlSpielzuege;
    if(anzahlSpielzuegeBissi%2 == 0)
        woBissiS = anzahlSpielzuege;
    else
        woBissiS = Math.floor(anzahlSpielzuege - 1);
    var wo = Math.round(woBissi/2);

    if(afW.length != anzahlSpielzuege)
    {
        for(var i=1; i<=anzahlSpielzuege; i++)
        {
            var altesfeldW = $("#lNotationsTableW tr:eq("+ i +") .SNP").text();
            afW.push($(".weiss"+altesfeldW)[0].innerHTML);
            console.log(afW);
        }
        if(anzahlSpielzuegeBissi%2 != 0)
        {
            for(var j=1; j<=anzahlSpielzuege-1; j++) {
                var altesfeldS = $("#lNotationsTableS tr:eq("+ j +") .SNP").text();
                afS.push($(".weiss"+altesfeldS)[0].innerHTML);
                console.log(afS);
            }
        }
        else
        {
            for(var k=1; k<=anzahlSpielzuege; k++) {
                var altesfeldS = $("#lNotationsTableS tr:eq("+ k +") .SNP").text();
                afS.push($(".weiss"+altesfeldS)[0].innerHTML);
                console.log(afS);
            }
        }
    }

    zugnummern(wo);*/
}