<?php
/**
 * Created by PhpStorm.
 * User: raphael
 * Date: 31.10.16
 * Time: 18:58
 */

//session_start();
//include("User.php");
//$x = new User;

//echo "Hallo";
    //echo $_POST["user"], $_POST["passwort"];
    echo $_POST["inputEmail1"], $_POST["inputPasswort1"];
    echo $_POST["inputEmail2"], $_POST["inputPasswort2"];
    //$x->login($_POST["inputEmailLogin"], $_POST["inputPasswortLogin"]);
//$x->login("r.lewitsch98@htl-ottakring.ac.at", "123");
?>
<html>
<body>
<h1>hallo</h1>
</body>
</html>
