<?php
/**
 * Created by PhpStorm.
 * User: raphael
 * Date: 30.10.16
 * Time: 19:11
 */

//$pw="userEins";
$pw="";
//$user="user1";
$user="root";
$server="localhost";
$db="chess4u";
$charset="utf8";
$opt=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];

?>