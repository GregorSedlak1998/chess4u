<?php
for ($i=1; $i<=8; $i++)
{
    ?>
    <tr>
        <th class="text-center"><?=$i?></th>
        <?php
        for ($j=8; $j>=1; $j--)
        {

            if($j%2 == 0)
            {
                if($i%2 != 0)
                {
                    $farbeHintergrund = "#e5e9ea";
                    //$farbeSchrift = "black";
                }
                else
                {
                    $farbeHintergrund = "#2b3336";
                    //$farbeSchrift = "gray";
                }
            }
            else if($j%2 != 0)
            {
                if($i%2 == 0)
                {
                    $farbeHintergrund = "#e5e9ea";
                    //$farbeSchrift = "black";
                }
                else
                {
                    $farbeHintergrund = "#2b3336";
                    //$farbeSchrift = "grey";
                }
            }

            if($j == 1)
                $tdId = "schwA".$i;
            if($j == 2)
                $tdId = "schwB".$i;
            if($j == 3)
                $tdId = "schwC".$i;
            if($j == 4)
                $tdId = "schwD".$i;
            if($j == 5)
                $tdId = "schwE".$i;
            if($j == 6)
                $tdId = "schwF".$i;
            if($j == 7)
                $tdId = "schwG".$i;
            if($j == 8)
                $tdId = "schwH".$i;
            //echo $tdId;
            ?>

            <td class="<?=$tdId?>" style='background-color: <?=$farbeHintergrund?>; text-align: center;'>
                <?php
                //echo $j;
                //echo $i;
                ?>
            </td>
            <!--<div style="background-color: white; color: black; width: 50px; height: 20px;">
                <?php
            /*                //echo $i;
                            //echo $j;
                            */?>
            </div>-->
            <?php
        }
        ?>
        <th class="text-center"><?=$i?></th>
    </tr>
    <?php
}
?>