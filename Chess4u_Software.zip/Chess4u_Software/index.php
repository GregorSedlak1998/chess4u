<?php
session_start();
include("User.php");
$x = new User;


$x -> IsLoggedIn();

$page;
if(!isset($_GET["page"]))
{
    $page="";
}
else
    $page = $_GET["page"];

//if(isset($_GET["page"]))
if($page == "log")
{
    //echo "Hallo";
    //echo $_POST["inputEmailLogin"], $_POST["inputPasswortLogin"];
    //$x->login($_POST["inputEmailLogin"], $_POST["inputPasswortLogin"]);
    if($x->login($_POST["inputEmailLogin"], $_POST["inputPasswortLogin"]))
        echo "PASST";
    else
    {
        $falschesLogin = "Die Email und das Passwort stimmen nicht über ein!";
    }
}
if($page == "startgame")
{
    if($_POST["inputEmail1"] != $_POST["inputEmail2"]) {
        if ($x->spielStarten($_POST["inputEmail1"], $_POST["inputPasswort1"], $_POST["inputEmail2"], $_POST["inputPasswort2"])) {
            echo "PASST";
        } else {
            $falschesLogin = "Es ist ein Fehler beim Login aufgetreten ..";
        }
    } else {
        $falschesLogin = "Es müssen zwei unterschiedliche Spieler sein!";
    }
}
?>
<html>
<head>
    <title>chess4u - login</title>

    <link rel="shortcut icon" href="http://chess4u.at/img/favicon.ico" type="image/x-icon">
    <link rel="icon" href="http://chess4u.at/img/favicon.ico" type="image/x-icon">

    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.css">
    <link rel="stylesheet" href="css2/style.css">

    <link rel="stylesheet" href="css2/inc/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css2/inc/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css2/style2.css">
    <link rel="stylesheet" href="css2/meins.css">
    <link rel="stylesheet" href="css2/mobile.css">


</head>
<body>


<nav id="main-navbar" class="navbar navbar-default navbar-fixed-top" role="navigation"> <!-- Classes: navbar-default, navbar-inverse, navbar-fixed-top, navbar-fixed-bottom, navbar-transparent. Note: If you use non-transparent navbar, set "height: 98px;" to #header -->
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand page-scroll" href="body">CHESS4U</a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                       aria-expanded="false">Login <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <form class="navbar-form" action="?page=log" method="POST">
                            <li>
                                <div class="form-group">
                                    <label class="sr-only" for="exampleInputEmail3">Email address</label>
                                    <input type="email" class="form-control" id="inputEmailLogin" name="inputEmailLogin"
                                           placeholder="Email">
                                </div>
                            </li>
                            <li role="separator" class="divider"></li>
                            <li>
                                <div class="form-group">
                                    <label class="sr-only" for="exampleInputPassword3">Password</label>
                                    <input type="password" class="form-control" id="inputPasswortLogin"
                                           name="inputPasswortLogin" placeholder="Password">
                                </div>
                            </li>
                            <li role="separator" class="divider"></li>
                            <li>
                                <button type="submit" class="btn btn-default">Sign in</button>
                            </li>
                        </form>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container" id="formDiv">
    <div class="row main">
        <div class="panel-heading">
            <div class="panel-title text-center">
                <?php
                //INSERT INTO `schachspiel` (`schachspiel_id`, `spieler_schwarz`, `spieler_weiß`, `spielbeginn`, `zeit_gesamt`, `zeit_spielerweiß`, `zeit_spielerschwarz`) VALUES (NULL, '4', '2', CURRENT_TIMESTAMP, NULL, NULL, NULL);

                        if(isset($falschesLogin))
                        {
                            ?>

                                <h5 style="color: red;"><?php echo $falschesLogin?></h5>

                            <?php
                        }
                ?>
                <h1 class="title">Spiel starten</h1>
                <h3>
                    <span class="glyphicon glyphicon-king"></span>
                    <span class="glyphicon glyphicon-queen"></span>
                    <span class="glyphicon glyphicon-pawn"></span>
                    <span class="glyphicon glyphicon-knight"></span>
                    <span class="glyphicon glyphicon-tower"></span>
                    <span class="glyphicon glyphicon-bishop"></span>
                </h3>
                <hr>
            </div>
        </div>

        <div class="main-login main-center">

            <form class="form-inline" action="?page=startgame" method="POST">
                <label for="">Spieler 1: </label><br>
                <div class="form-group input-group">
                    <span class="input-group-addon" id="addonEmail1"><span class="glyphicon glyphicon-envelope"></span></span>
                    <input type="email" class="form-control" aria-describedby="addonEmail1" id=inputEmail1" name="inputEmail1"
                           placeholder="Email">
                </div>
                <br><br>
                <div class="form-group input-group">
                    <span class="input-group-addon" id="addonPasswort1"><span class="glyphicon glyphicon-lock"></span></span>
                    <input type="password" class="form-control" aria-describedby="addonPasswort1"
                           id="inputPasswort1" name="inputPasswort1"
                           placeholder="Password">
                </div>
                <br><br>
                <label for="">Spieler 2:</label><br>
                <div class="form-group input-group">
                    <span class="input-group-addon" id="addonEmail2"><span class="glyphicon glyphicon-envelope"></span></span>
                    <input type="email" class="form-control" aria-describedby="addonEmail2" id="inputEmail2" name="inputEmail2"
                           placeholder="Email">
                </div>
                <br><br>
                <div class="form-group input-group">
                    <span class="input-group-addon" id="addonPasswort2"><span class="glyphicon glyphicon-lock"></span></span>
                    <input type="password" class="form-control" aria-describedby="addonPasswort2"
                           id="inputPasswort2" name="inputPasswort2"
                           placeholder="Password">
                </div>
                <br><br>
                <div class="form-group center">
                    <button type="submit" class="btn btn-default">Starten</button>
                </div>
            </form>

        </div>
    </div>
</div>

<script src="bower_components/jquery/dist/jquery.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.js"></script>


<?php



?>
</body>
</html>
