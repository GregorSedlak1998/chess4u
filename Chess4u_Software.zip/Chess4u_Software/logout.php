<?php
/**
 * Created by PhpStorm.
 * User: raphael
 * Date: 26.02.17
 * Time: 20:32
 */
session_start();
include("User.php");
$x = new User;
?>

<html>
<head>
    <title>chess4u - logout</title>
    <link rel="shortcut icon" href="http://chess4u.at/img/favicon.ico" type="image/x-icon">
    <link rel="icon" href="http://chess4u.at/img/favicon.ico" type="image/x-icon">

    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.css">
    <link rel="stylesheet" href="css2/style.css">

    <link rel="stylesheet" href="css2/inc/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css2/inc/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css2/style2.css">
    <link rel="stylesheet" href="css2/meins.css">
    <link rel="stylesheet" href="css2/mobile.css">
</head>
<body>


<nav id="main-navbar" class="navbar navbar-default" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand page-scroll" href="#">CHESS4U</a>
        </div>
    </div>
</nav>

<div class="container" id="formDiv">
    <div class="row main">
        <div class="panel-heading">
            <div class="panel-title text-center">


                <?php
                if ($x->logout()) {
                    ?><h5>ausgelogt.<a class='color' href='index.php'>einlogen?</a></h5><?php
                }
                ?>


                
            </div>
        </div>
    </div>
</div>

<script src="bower_components/jquery/dist/jquery.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.js"></script>


<?php



?>
</body>
</html>
