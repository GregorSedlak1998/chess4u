<?php
/**
 * Created by PhpStorm.
 * User: raphael
 * Date: 01.02.17
 * Time: 23:15
 */



$zeilen = readfile('localhost/client2.php');

?>

