<?php
for ($i=8; $i>=1; $i--)
{
    ?>
    <tr>
        <th class="text-center"><?=$i?></th>
        <?php
        for ($j="A"; $j<="H"; $j++)
        {

            //echo "Feld " + $i + "/" + $j;
            //echo "'".$j."".$i."',";

            $farbeHintergrund = "black";
            //$farbeSchrift = "white";
            if($j == "B" || $j == "D" || $j == "F" || $j == "H")
            {
                if($i%2 != 0)
                {
                    $farbeHintergrund = "white";
                    //$farbeSchrift = "black";
                }
                else
                {
                    $farbeHintergrund = "#2b3336";
                    //$farbeSchrift = "gray";
                }
            }
            else if($j == "A" || $j == "C" || $j == "E" || $j == "G")
            {
                if($i%2 == 0)
                {
                    $farbeHintergrund = "white";
                    //$farbeSchrift = "black";
                }
                else
                {
                    $farbeHintergrund = "#2b3336";
                    //$farbeSchrift = "grey";
                }
            }

            $tdId = "weiss".$j.$i;
            //echo $tdId;
            ?>

            <td class="<?=$tdId?>" style='background-color: <?=$farbeHintergrund?>; text-align: center;'>
                <?php
                //echo $j;
                //echo $i;
                ?>
            </td>
            <!--<div style="background-color: white; color: black; width: 50px; height: 20px;">
                <?php
            /*                //echo $i;
                            //echo $j;
                            */?>
            </div>-->
            <?php
        }
        ?>
        <th class="text-center"><?=$i?></th>
    </tr>
    <?php
}
?>