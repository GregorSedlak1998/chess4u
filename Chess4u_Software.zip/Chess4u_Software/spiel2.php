<!doctype html>
<html lang="de">
<head>

    <title>chess4u - spiel2</title>

    <script src="js/spiel.js"></script>

    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.css">
    <link rel="stylesheet" href="css/style_alt.css">


</head>
<body onload="init()">

<div id="divAll" class="container col-md-12">
    <div id="divWeiss" class="container col-md-12">
        <div class="container">
            <table id="schachbrettWeiss">
                <tr>
                    <th class="text-center"></th>
                    <th class="text-center">A</th>
                    <th class="text-center">B</th>
                    <th class="text-center">C</th>
                    <th class="text-center">D</th>
                    <th class="text-center">E</th>
                    <th class="text-center">F</th>
                    <th class="text-center">G</th>
                    <th class="text-center">H</th>
                    <th class="text-center"></th>
                </tr>
                <?php
                include('brettWeiss.php');
                ?>
                <tr>
                    <th class="text-center"></th>
                    <th class="text-center">A</th>
                    <th class="text-center">B</th>
                    <th class="text-center">C</th>
                    <th class="text-center">D</th>
                    <th class="text-center">E</th>
                    <th class="text-center">F</th>
                    <th class="text-center">G</th>
                    <th class="text-center">H</th>
                    <th class="text-center"></th>
                </tr>
            </table>
        </div>
    </div>
</div>


<script src="bower_components/jquery/dist/jquery.js"></script>
<!--<script src="js/js.js"></script>-->

</body>
</html>