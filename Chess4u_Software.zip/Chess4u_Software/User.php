<?php



class User
{
    public function spielStarten($email1, $pwd1, $email2, $pwd2) //user, pwd
    {
        $pw="";
        $userdb="root";
        $server="localhost";
        $db="chess4u";
        $charset="utf8";
        $opt=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];

        $connection = new PDO("mysql: host=$server; dbname=$db; charset=$charset",$userdb,$pw,$opt);
        if(!$connection)
        {
            error_log("Error!");
            die("Datenbankfehler");
        }
        $control1 = 0;
        $control2 = 0;
        //$isAdmin = 0;
        //infos zum admin (falls wir das noch brauchen) unter /Users/raphael/Documents/Schule/INSY/letztes Jahr/Projekt_Flug/program1/User.php
        $statement1 = $connection->prepare("SELECT * FROM `spieler` WHERE email = :email1 and passwort = :pw1");
        $statement1->bindParam(':email1',$email1,PDO::PARAM_STR);
        $statement1->bindParam(':pw1',$pwd1,PDO::PARAM_STR);
        $statement1->execute();
        $statement2 = $connection->prepare("SELECT * FROM `spieler` WHERE email = :email2 and passwort = :pw2");
        $statement2->bindParam(':email2',$email2,PDO::PARAM_STR);
        $statement2->bindParam(':pw2',$pwd2,PDO::PARAM_STR);
        $statement2->execute();
        /*$statement2 = $connection->prepare("SELECT * FROM `login` WHERE user = :userr2 and passwort = :pw2 and enabled = 'true' and isAdmin = 'true'");
        $statement2->bindParam(':userr2',$user,PDO::PARAM_STR);
        $statement2->bindParam(':pw2',$pwd,PDO::PARAM_STR);
        $statement2->execute();*/

        //$row = $statement->fetch(PDO::FETCH_ASSOC);
        //while ($statement->rowCount() > 0)
        while ($row1 = $statement1->fetch())
        {
            //echo $row;
            $control1++;
            extract($row1);
            $sp1 = $row1['id'];
            //$game = "x";
            //$user = $row['id'] + "_" + $row['nachname'] + "_" + $row['vorname'];
            //echo "   user: " + $game;
        }
        while ($row2 = $statement2->fetch())
        {
            $control2++;
            extract($row2);
            $sp2 = $row2['id'];
        }


        //$user = $email;
        /*while($row = $statement2->fetch())
        {
            $isAdmin++;
        }*/
        //if ($user !== false)
        if($control1 > 0 && $control2 > 0)
        {
            $statement3 = $connection->prepare("INSERT INTO `schachspiel` (`spieler_schwarz`, `spieler_weiß`, `spielbeginn`, `zeit_gesamt`, `zeit_spielerweiß`, `zeit_spielerschwarz`) VALUES (:sp2, :sp1, CURRENT_TIMESTAMP, NULL, NULL, NULL);");
            $statement4 = $connection->prepare("SELECT * FROM `schachspiel` ORDER BY `schachspiel_id` DESC LIMIT 1;");
            $statement3->bindParam(':sp1',$sp1,PDO::PARAM_STR);
            $statement3->bindParam(':sp2',$sp2,PDO::PARAM_STR);
            $statement3->execute();
            $statement4->execute();

            while ($row4 = $statement4->fetch())
            {
                extract($row4);
                $gameId = $row4['schachspiel_id'];
            }

            header("Location: ../da/spiel.php?sp1=".$sp1."&sp2=".$sp2);

            $_SESSION["spiel"] = $gameId;

            echo "PASST!";
        }
        /*if($isAdmin != 0)
        {
            $_SESSION["username_admin"] = $user;
            header("location: login.php?page=admin");
        }*/
        else
        {
            echo "FALSCH";
        }
    }

    public function login($email, $pwd) //user, pwd
    {
        $pw = "";
        $userdb = "root";
        $server = "localhost";
        $db = "chess4u";
        $charset = "utf8";
        $opt = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC];

        $connection = new PDO("mysql: host=$server; dbname=$db; charset=$charset", $userdb, $pw, $opt);
        if (!$connection) {
            error_log("Error!");
            die("Datenbankfehler");
        }
        $control = 0;
        //$isAdmin = 0;
        //infos zum admin (falls wir das noch brauchen) unter /Users/raphael/Documents/Schule/INSY/letztes Jahr/Projekt_Flug/program1/User.php
        $statement = $connection->prepare("SELECT * FROM `spieler` WHERE email = :email and passwort = :pw");
        $statement->bindParam(':email', $email, PDO::PARAM_STR);
        $statement->bindParam(':pw', $pwd, PDO::PARAM_STR);
        $statement->execute();
        /*$statement2 = $connection->prepare("SELECT * FROM `login` WHERE user = :userr2 and passwort = :pw2 and enabled = 'true' and isAdmin = 'true'");
        $statement2->bindParam(':userr2',$user,PDO::PARAM_STR);
        $statement2->bindParam(':pw2',$pwd,PDO::PARAM_STR);
        $statement2->execute();*/

        //$row = $statement->fetch(PDO::FETCH_ASSOC);
        //while ($statement->rowCount() > 0)
        while ($row = $statement->fetch()) {
            //echo $row;
            $control++;
            extract($row);
            $user = $id + "_" + $nachname + "_" + $vorname;
            //$user = $row['id'] + "_" + $row['nachname'] + "_" + $row['vorname'];
            echo "   user: " + $user;
        }


        //$user = $email;
        /*while($row = $statement2->fetch())
        {
            $isAdmin++;
        }*/
        //if ($user !== false)
        if ($control > 0) {
            $_SESSION["username"] = $user;
            header("Location: login.php");
            //echo "PASST!";
            return true;
        } /*if($isAdmin != 0)
        {
            $_SESSION["username_admin"] = $user;
            header("location: login.php?page=admin");
        }*/
        else {
            //echo "FALSCH";
            return false;
        }
    }

    public function logout()
    {
        session_destroy();
        return true;
        //echo "<h3>ausgelogt.<a class='color' href='index.php'>einlogen?</a></h3>";
    }

    public function IsLoggedIn()
    {
        if(isset($_SESSION["username"]))
        {

            return true;

            //$session = $_SESSION["username"];
            //echo "ANGEMELDET als ".$session."!";

            ?>
<!--            <br><br><a class="links_a color" id="link_logout" href="login.php?page=logout">Abmelden</a>-->
            <?php
        }
        /*else
        {
            //echo "Sie sind nicht angemeldet!";
        }*/
    }

    public function IsGameActiv()
    {
        if(isset($_SESSION["spiel"]))
        {
            return true;
        }
    }
   /* public function Register($userRegister, $mailRegister, $pwdRegister)
    {
        $key = 0;
        $pw="";
        $user="root";
        $server="localhost";
        $db="flugreise";
        $charset="utf8";
        $opt=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];
        $connection = new PDO("mysql: host=$server; dbname=$db; charset=$charset",$user,$pw,$opt);
        if(!$connection)
        {
            error_log("Error");
            die("Datenbankfehler");
        }
        $statement = $connection->prepare("INSERT INTO login (user,mail,passwort,isAdmin,enabled) VALUES (?,?,?,'false','false')");
        $statement->execute([$userRegister,$mailRegister,$pwdRegister]);
        $statement2 = $connection->prepare("SELECT * FROM login WHERE user = ?");
        $statement2->execute([$userRegister]);
        while($row = $statement2->fetch())
        {
            echo "Hallo ".$user."1";
            //$blabla = $row->user;
            //echo "Hallo ".$blabla."!";
            //echo " Sie müssen vom Admin enabled werden!";
            echo "Der schlüssel wird übergeben";
            //.$key = 1;
        }

    }*/
    /* public function EnableAccount($key)
	{
		if($key = 1)
		{
			//$id = filter_input(INPUT_POST,'userID');
			echo $blabla;

			include("settings.inc");
			$connection = mysql_connect($server,$serverUser,$password); //verbindung starten
			if(!$connection) //wenn man keine Verbindung herstellen kann ...
			{
				echo "Fehler!"; // ... gibt man eine Fehlermeldung aus
				echo mysql_error();
			}
			mysql_select_db($dbname);
			$fuellen = "UPDATE `login` SET `enabled`= 'true' WHERE user='$blabla'";
			$ergebnis = mysql_query($fuellen);
			mysql_close($connection);

			echo "  ENABLED!";
			echo "<h3>ausgelogt.<a class='color' href='index.php?page=admin'>zur�ck</a></h3>";
		}
	}*/
}
?>