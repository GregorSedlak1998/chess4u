/**
 * Created by raphael on 27.11.16.
 */
var socket;

function welcheFigur(figur) {
    // if (figur == '76CA0424')
    // {
    //     return "<span border='1px solid black' style='color: #757778' class='glyphicon glyphicon-king'></span>";
    // }
    // if(figur == '04AA615A6D3B80')
    //     return "<span border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-king'></span>";
    if (figur == 'WK')
    {
        return "<span border='1px solid black' style='color: #757778' class='glyphicon glyphicon-king'></span>";
    }
    else if (figur == 'WD')
    {
        return "<span border='1px solid black' style='color: #757778' class='glyphicon glyphicon-queen'></span>";
    }
    else if (figur == 'WL')
    {
        return "<span border='1px solid black' style='color: #757778' class='glyphicon glyphicon-pawn'></span>";
    }
    else if (figur == 'WS')
    {
        return "<span border='1px solid black' style='color: #757778' class='glyphicon glyphicon-knight'></span>";
    }
    else if (figur == 'WT')
    {
        return "<span border='1px solid black' style='color: #757778' class='glyphicon glyphicon-tower'></span>";
    }
    else if (figur == 'WB')
    {
        return "<span border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop'></span>";
    }
    if (figur == 'SK')
    {
        return "<span border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-king'></span>";
    }
    else if (figur == 'SD')
    {
        return "<span border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-queen'></span>";
    }
    else if (figur == 'SL')
    {
        return "<span border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-pawn'></span>";
    }
    else if (figur == 'SS')
    {
        return "<span border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-knight'></span>";
    }
    else if (figur == 'ST')
    {
        return "<span border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-tower'></span>";
    }
    else if (figur == 'SB')
    {
        return "<span border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop'></span>";
    }

}
function welchePosition(feld, figur) {
    $(".weiss"+feld)[0].innerHTML = welcheFigur(figur);
}
function addNotationsListe(altesFeld, feld, farbe, figur) {
    var nrW = $("#kNotationsTableW tr").length;
    var nrS = $("#kNotationsTableS tr").length;

    if(altesFeld != '00')
    {
        if(farbe=='W')
        {
            document.getElementById("kNotationsTableW").innerHTML += "<tr><td>" + nrW + "</td><td>" + feld + "</td></tr>";

            var j = $("#kNotationsTableW tr:eq(" + nrW +") td:eq(0)").text();
            var jW = $("#kNotationsTableW tr:eq(" + nrW +") td:eq(1)").text();
            var html = "<tr><td class='text-center'>"+j+"</td><td class='text-center'>"+jW+"</td><td class='text-center'></td></tr>";
            $("#kNotationsTable").append(html);

            if(figur == "B")
            {
                document.getElementById("lNotationsTableW").innerHTML += "<tr><td>" + nrW + "</td><td>" + altesFeld + "-" + feld + "</td></tr>";
            }
            else
            {
                document.getElementById("lNotationsTableW").innerHTML += "<tr><td>" + nrW + "</td><td>" + figur + "" + altesFeld + "-" + feld + "</td></tr>";
            }

            var jW2 = $("#lNotationsTableW tr:eq(" + nrW +") td:eq(1)").text();
            var html2 = "<tr><td class='text-center'>"+j+"</td><td class='text-center'>"+jW2+"</td><td class='text-center'></td></tr>";
            $("#lNotationsTable").append(html2);

        }
        else if(farbe='S')
        {
            document.getElementById("kNotationsTableS").innerHTML += "<tr><td>" + nrS + "</td><td>" + feld + "</td></tr>";

            var jS = $("#kNotationsTableS tr:eq(" + nrS +") td:eq(1)").text();
            $("#kNotationsTable tr:eq(" + nrS +") td:eq(2)").html(jS);

            if(figur == "B")
            {
                document.getElementById("lNotationsTableS").innerHTML += "<tr><td>" + nrS + "</td><td>" + altesFeld + "-" + feld + "</td></tr>";
            }
            else
            {
                document.getElementById("lNotationsTableS").innerHTML += "<tr><td>" + nrS + "</td><td>" + figur + "" + altesFeld + "-" + feld + "</td></tr>";
            }

            var jS2 = $("#lNotationsTableS tr:eq(" + nrS +") td:eq(1)").text();
            $("#lNotationsTable tr:eq(" + nrS +") td:eq(2)").html(jS2);
        }
    }
}
/*function whichFirstAltesFeld(neuesFeld, altesFeld, figur) {
    if(neuesFeld == 'E3' && figur.substr(0,2) == 'WB')//c3, e3, d4, h5, d6, f6, e5
    {
        return 'E2';
    }
    else if(neuesFeld == 'C3' && figur.substr(0,2) == 'WB')
    {
        return 'C2';
    }
    else if(neuesFeld == 'D4' && altesFeld != 'D3' && figur.substr(0,2) == 'WB')
    {
        return 'D2';
    }
    else if(neuesFeld == 'H5' && altesFeld != 'H6' && figur.substr(0,2) == 'SB')
    {
        return 'H7';
    }
    else if(neuesFeld == 'D6' && figur.substr(0,2) == 'SB')
    {
        return 'D7';
    }
    else if(neuesFeld == 'F6' && figur.substr(0,2) == 'SB')
    {
        return 'F7';
    }
    else if(neuesFeld == 'E5' && altesFeld != 'E6' && figur.substr(0,2) == 'SB')
    {
        return 'E7';
    }
    else {
        return altesFeld;
    }
}*/
function altePosition(altesFeld) {
    $(".weiss"+altesFeld)[0].innerHTML = "";
}

function welcheAlteFigur(figur) {
    if (figur == 'WD1')
    {
        $("#afwd").removeClass('afwFigur');
    }
    else if (figur == 'WL1')
    {
        $("#afwl1").removeClass('afwFigur');
    }
    else if (figur == 'WL2')
    {
        $("#afwl2").removeClass('afwFigur');
    }
    else if (figur == 'WS1')
    {
        $("#afws1").removeClass('afwFigur');
    }
    else if (figur == 'WS2')
    {
        $("#afws2").removeClass('afwFigur');
    }
    else if (figur == 'WT1')
    {
        $("#afwt1").removeClass('afwFigur');
    }
    else if (figur == 'WT2')
    {
        $("#afwt2").removeClass('afwFigur');
    }
    else if (figur == 'WB1')
    {
        $("#afwb1").removeClass('afwFigur');
    }
    else if (figur == 'WB2')
    {
        $("#afwb2").removeClass('afwFigur');
    }
    else if (figur == 'WB3')
    {
        $("#afwb3").removeClass('afwFigur');
    }
    else if (figur == 'WB4')
    {
        $("#afwb4").removeClass('afwFigur');
    }
    else if (figur == 'WB5')
    {
        $("#afwb5").removeClass('afwFigur');
    }
    else if (figur == 'WB6')
    {
        $("#afwb6").removeClass('afwFigur');
    }
    else if (figur == 'WB7')
    {
        $("#afwb7").removeClass('afwFigur');
    }
    else if (figur == 'WB8')
    {
        $("#afwb8").removeClass('afwFigur');
    }
    else if (figur == 'SD1')
    {
        $("#afsd").removeClass('afwFigur');
    }
    else if (figur == 'SL1')
    {
        $("#afsl1").removeClass('afwFigur');
    }
    else if (figur == 'SL2')
    {
        $("#afsl2").removeClass('afwFigur');
    }
    else if (figur == 'SS1')
    {
        $("#afss1").removeClass('afwFigur');
    }
    else if (figur == 'SS2')
    {
        $("#afss2").removeClass('afwFigur');
    }
    else if (figur == 'ST1')
    {
        $("#afst1").removeClass('afwFigur');
    }
    else if (figur == 'ST1')
    {
        $("#afst2").removeClass('afwFigur');
    }
    else if (figur == 'SB1')
    {
        $("#afsb1").removeClass('afsFigur');
    }
    else if (figur == 'SB2')
    {
        $("#afsb2").removeClass('afsFigur');
    }
    else if (figur == 'SB3')
    {
        $("#afsb3").removeClass('afsFigur');
    }
    else if (figur == 'SB4')
    {
        $("#afsb4").removeClass('afsFigur');
    }
    else if (figur == 'SB5')
    {
        $("#afsb5").removeClass('afsFigur');
    }
    else if (figur == 'SB6')
    {
        $("#afsb6").removeClass('afsFigur');
    }
    else if (figur == 'SB7')
    {
        $("#afsb7").removeClass('afsFigur');
    }
    else if (figur == 'SB8')
    {
        $("#afsb8").removeClass('afsFigur');
    }

}

function init() {
    var host = "ws://localhost:8080";
    try {
        socket = new WebSocket(host);
        console.log('WebSocket - status '+socket.readyState);
        socket.onopen    = function(msg) {
            console.log("Welcome - status "+this.readyState);
        };
        socket.onmessage = function(msg) {
            console.log("Received: "+msg.data);
            if (msg.data == 'spielende')
            {
                alert("Spiel beendet!");

            }
            else if (msg.data.substr(0,3) == 'af:')
            {
                if (msg.data.substr(3,1) == 'W')
                {
                    fw = msg.data.substr(3,3);
                    welcheAlteFigur(fw);
                }
                else if (msg.data.substr(3,1) == 'S')
                {
                    fs = msg.data.substr(3,3);
                    welcheAlteFigur(fs);
                }
            }
            else {
                var altesFeld = msg.data.substr(0,2);
                var feld = msg.data.substr(3,2);
                var figur = msg.data.substr(6,2); //14, 8
                var farbe = msg.data.substr(6,1);
                //var altesFeld = whichFirstAltesFeld(feld, altesFeld_1, figur);
                var figurGenau = msg.data.substr(7,1);
                addNotationsListe(altesFeld, feld, farbe, figurGenau);
                for(var i = 8; i>=1; i--)
                {
                    var abc = 'ABCDEFGH';
                    for(var j=0;j<abc.length;j++)
                    {
                        var feldx = ''+abc[j]+''+i;
                        if(altesFeld == feldx)
                        {
                            welchePosition(feld, figur);
                        }
                        if(feld == feldx)
                        {
                            altePosition(altesFeld);
                            console.log(feld);
                            console.log(figur);
                        }
                    }
                }
            }
        };
        socket.onclose   = function(msg) {
            console.log("Disconnected - status "+this.readyState);
        };
    }
    catch(ex){
        log(ex);
    }
}
 function quit(){
 if (socket != null) {
 console.log("Goodbye!");
 socket.close();
 socket=null;
 }
 }