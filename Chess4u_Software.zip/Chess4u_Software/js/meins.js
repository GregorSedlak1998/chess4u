$('#myTab a').click(function (e) {
    e.preventDefault()
    $(this).tab('show')
});

$("#spielStarten").on("click", function () {
    $.ajax({
        url: 'http://localhost/senddata.py',
        success: function(response) {
            // here you do whatever you want with the response variable
            console.log("!");
        }
    });
    console.log("senddata");
});
