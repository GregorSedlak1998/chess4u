<?php

    //require __DIR__ . '../../../../Users/raphael/Documents/Schule/Diplomarbeit/libs/da/vendor/autoload.php';
require __DIR__ . '/vendor/autoload.php';

Ratchet\Client\connect('ws://127.0.0.1:8080')->then(function ($conn) {
    $conn->on('message', function ($msg) use ($conn) {
        echo "Received: {$msg}\n";
        $conn->close();
    });
    $conn->send($_GET['id']);
    $conn->close();
}, function ($e) {
    echo "Could not connect: {$e->getMessage()}\n";
});

    /*$loop = React\EventLoop\Factory::create();
    $connector = new Ratchet\Client\Connector($loop);

    $connector('ws://127.0.0.1:8080', ['protocol1', 'subprotocol2'], ['Origin' => 'http://'])
    ->then(function(Ratchet\Client\WebSocket $conn) {
    $conn->on('message', function(\Ratchet\RFC6455\Messaging\MessageInterface $msg) use ($conn) {
    echo "Received: {$msg}\n";
    $conn->close();
    });

    $conn->on('close', function($code = null, $reason = null) {
    echo "Connection closed ({$code} - {$reason})\n";
    });

    $conn->send('Hello World!');
    }, function(\Exception $e) use ($loop) {
    echo "Could not connect: {$e->getMessage()}\n";
    $loop->stop();
    });

    $loop->run();*/

?>