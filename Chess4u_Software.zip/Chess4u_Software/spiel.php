<?php
session_start();
include("../ts1/User.php");
$x = new User;

if($x -> IsGameActiv())
    $game = $_SESSION["spiel"];
else
    header('Location: ../ts1/index.php');

$sp1 = $_GET['sp1'];
$sp2 = $_GET['sp2'];

$pw="";
$userdb="root";
$server="localhost";
$db="chess4u";
$charset="utf8";
$opt=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];

$connection = new PDO("mysql: host=$server; dbname=$db; charset=$charset",$userdb,$pw,$opt);
if(!$connection)
{
    error_log("Error!");
    die("Datenbankfehler");
}
$statement1 = $connection->prepare("SELECT * FROM `spieler` WHERE id=:id");
$statement1->bindParam(':id',$sp1,PDO::PARAM_STR);
$statement1->execute();
$statement2 = $connection->prepare("SELECT * FROM `spieler` WHERE id=:id");
$statement2->bindParam(':id',$sp2,PDO::PARAM_STR);
$statement2->execute();

while ($row1 = $statement1->fetch())
{
    extract($row1);
    $spielerW = $row1['nachname'];
}
while ($row2 = $statement2->fetch())
{
    extract($row2);
    $spielerS = $row2['nachname'];
}

?>
<html>
<head>
    <title>chess4u - spiel</title>

    <script src="js/spiel.js"></script>

    <link rel="shortcut icon" href="http://chess4u.at/img/favicon.ico" type="image/x-icon">
    <link rel="icon" href="http://chess4u.at/img/favicon.ico" type="image/x-icon">

    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="css/inc/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/inc/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style2.css">
    <link rel="stylesheet" href="css/meins.css">
    <link rel="stylesheet" href="css/mobile.css">
</head>
<body onload="init()">

<nav id="main-navbar" class="navbar navbar-default" role="navigation"> <!-- Classes: navbar-default, navbar-inverse, navbar-fixed-top, navbar-fixed-bottom, navbar-transparent. Note: If you use non-transparent navbar, set "height: 98px;" to #header -->
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand page-scroll" href="body">CHESS4U</a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Spiel <?php //echo $game;?></a>
                    <ul class="dropdown-menu">
                        <form class="navbar-form" action="?page=log" method="POST">
                            <li>
                                <label for=""><a href="spielBeenden.php">Spiel beenden</a></label>
                            </li>
                        </form>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container" id="formDiv">
    <div id="divAll" class="container col-md-12">
        <div id="divAllLinks" style="padding-left: 50px;" class="container col-md-4 col-sm-4">
<!--            <h2 class="text-center">Partie</h2><br>-->

<!--            <a href='spiel.php?spiel=start' >Spiel Starten</a>-->
            <h4><span style="color: #65d9f2;">Schwarz: </span><?php echo $spielerS?></h4>
            <h4><span style="color: #757778;">Weiß: </span><?php echo $spielerW?></h4>

            <br><br>

            <ul>
                <li><a style="color: #2b3336;" href="#kNotationTables" aria-controls="kNotationTables" role="tab" data-toggle="tab">Kurze Notation</a></li>
                <li><a href="#lNotationTables" aria-controls="lNotationTables" role="tab" data-toggle="tab">Lange Notation</a></li>
            </ul>
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane" id="kNotationTables">
                    <table id="kNotationsTable" class="table table-striped table-responsive table-bordered"> <!--id="kNotationsTable"-->
                        <tr>
                            <th class="text-center">NR</th>
                            <th class="text-center"><?php echo $spielerW?></th>
                            <th class="text-center"><?php echo $spielerS?></th>
                        </tr>
                    </table>

                    <table hidden id="kNotationsTableW" class="table table-striped table-responsive table-bordered">
                        <tr>
                            <th class="text-center">NR</th>
                            <th class="text-center"><?php echo $spielerW ?></th>
                        </tr>
                    </table>
                    <table hidden id="kNotationsTableS" class="table table-striped table-responsive table-bordered">
                        <tr>

                            <th class="text-center">NR</th>
                            <th class="text-center"><?php echo $spielerS ?></th>
                        </tr>
                    </table>
                </div>
                <div role="tabpanel" class="tab-pane" id="lNotationTables">
                    <table id="lNotationsTable" class="table table-striped table-responsive table-bordered"> <!--id="kNotationsTable"-->
                        <tr>
                            <th class="text-center">NR</th>
                            <th class="text-center"><?php echo $spielerW?></th>
                            <th class="text-center"><?php echo $spielerS?></th>
                        </tr>
                    </table>
                    <table hidden id="lNotationsTableW" class="table table-striped table-responsive table-bordered">
                        <tr>
                            <th class="text-center">NR</th>
                            <th class="text-center"><?php echo $spielerW ?></th>
                        </tr>
                    </table>
                    <table hidden id="lNotationsTableS" class="table table-striped table-responsive table-bordered">
                        <tr>

                            <th class="text-center">NR</th>
                            <th class="text-center"><?php echo $spielerS ?></th>
                        </tr>
                    </table>
                </div>
            </div>

            <!--<button class="btn btn-default" type="submit">Drucken</button>
            <button class="btn btn-default" type="submit">Speichern</button>-->
            <br>
<!--             <a href="../ts1/index.php">anmelden</a>-->
        </div>
        <div id="divWeiss" class="container col-md-5 col-md-offset-2 col-sm-offset-3 col-sm-5 col-xs-12">
            <div class="text-center" id="afs">
                <span id="afsd" border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-queen afsFigur'></span>
                <span id="afst1" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-tower afsFigur'></span>
                <span id="afst2" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-tower afsFigur'></span>
                <span id="afsl1" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-pawn afsFigur'></span>
                <span id="afsl2" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-pawn afsFigur'></span>
                <span id="afss1" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-knight afsFigur'></span>
                <span id="afss2" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-knight afsFigur'></span>
                <span id="afsb1" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop afsFigur'></span>
                <span id="afsb2" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop afsFigur'></span>
                <span id="afsb3" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop afsFigur'></span>
                <span id="afsb4" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop afsFigur'></span>
                <span id="afsb5" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop afsFigur'></span>
                <span id="afsb6" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop afsFigur'></span>
                <span id="afsb7" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop afsFigur'></span>
                <span id="afsb8" hidden border='1px solid black' style='color: #65d9f2' class='glyphicon glyphicon-bishop afsFigur'></span>
            </div>
            <table id="schachbrettWeiss">
                <tr>
                    <th class="text-center"></th>
                    <th class="text-center">A</th>
                    <th class="text-center">B</th>
                    <th class="text-center">C</th>
                    <th class="text-center">D</th>
                    <th class="text-center">E</th>
                    <th class="text-center">F</th>
                    <th class="text-center">G</th>
                    <th class="text-center">H</th>
                    <th class="text-center"></th>
                </tr>
                <?php
                include('brettWeiss.php');
                ?>
                <tr>
                    <th class="text-center"></th>
                    <th class="text-center">A</th>
                    <th class="text-center">B</th>
                    <th class="text-center">C</th>
                    <th class="text-center">D</th>
                    <th class="text-center">E</th>
                    <th class="text-center">F</th>
                    <th class="text-center">G</th>
                    <th class="text-center">H</th>
                    <th class="text-center"></th>
                </tr>
            </table>
            <div class="text-center" id="afw">
                <span id="afwd" border='1px solid black' style='color: #757778' class='glyphicon glyphicon-queen afwFigur'></span>
                <span id="afwt1" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-tower afwFigur'></span>
                <span id="afwt2" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-tower afwFigur'></span>
                <span id="afwl1" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-pawn afwFigur'></span>
                <span id="afwl2" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-pawn afwFigur'></span>
                <span id="afws1" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-knight afwFigur'></span>
                <span id="afws2" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-knight afwFigur'></span>
                <span id="afwb1" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop afwFigur'></span>
                <span id="afwb2" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop afwFigur'></span>
                <span id="afwb3" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop afwFigur'></span>
                <span id="afwb4" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop afwFigur'></span>
                <span id="afwb5" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop afwFigur'></span>
                <span id="afwb6" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop afwFigur'></span>
                <span id="afwb7" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop afwFigur'></span>
                <span id="afwb8" hidden border='1px solid black' style='color: #757778' class='glyphicon glyphicon-bishop afwFigur'></span>
            </div>
        </div>
    </div>
</div>

<script src="bower_components/jquery/dist/jquery.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.js"></script>
<script src="js/meins.js"></script>

</body>
</html>
